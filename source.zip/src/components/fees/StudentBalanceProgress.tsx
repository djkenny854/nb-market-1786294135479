
import React from 'react';
import { Progress } from '@/components/ui/progress';

interface StudentBalanceProgressProps {
  totalPaid: number;
  totalRequired: number;
  size?: 'sm' | 'md' | 'lg';
}

const StudentBalanceProgress: React.FC<StudentBalanceProgressProps> = ({ 
  totalPaid, 
  totalRequired, 
  size = 'md' 
}) => {
  const progress = totalRequired > 0 ? Math.min((totalPaid / totalRequired) * 100, 100) : 0;
  
  const sizeConfig = {
    sm: { container: 32, stroke: 2, text: 'text-xs' },
    md: { container: 40, stroke: 3, text: 'text-sm' },
    lg: { container: 48, stroke: 4, text: 'text-base' }
  };

  const config = sizeConfig[size];
  const radius = (config.container - config.stroke * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const getProgressColor = () => {
    if (progress >= 100) return '#10b981'; // green-500
    if (progress >= 75) return '#3b82f6'; // blue-500
    if (progress >= 25) return '#f59e0b'; // amber-500
    return '#ef4444'; // red-500
  };

  const CircularProgress = () => (
    <div className="relative" style={{ width: config.container, height: config.container }}>
      <svg
        className="transform -rotate-90"
        width={config.container}
        height={config.container}
      >
        {/* Background circle */}
        <circle
          cx={config.container / 2}
          cy={config.container / 2}
          r={radius}
          stroke="#e5e7eb"
          strokeWidth={config.stroke}
          fill="none"
        />
        {/* Progress circle */}
        <circle
          cx={config.container / 2}
          cy={config.container / 2}
          r={radius}
          stroke={getProgressColor()}
          strokeWidth={config.stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className="transition-all duration-500 ease-in-out"
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={`font-semibold ${config.text}`}>
          {Math.round(progress)}%
        </span>
      </div>
    </div>
  );

  return (
    <div className="flex items-center space-x-3">
      <CircularProgress />
      <div className="flex-1 min-w-0">
        <div className={`${config.text} text-gray-600 mb-1`}>
          Payment Progress
        </div>
        <div className="flex justify-between text-xs text-gray-500">
          <span>Paid: UGX {totalPaid.toLocaleString()}</span>
          <span>Total: UGX {totalRequired.toLocaleString()}</span>
        </div>
        <div className="text-xs text-gray-500 mt-1">
          Balance: UGX {(totalRequired - totalPaid).toLocaleString()}
        </div>
      </div>
    </div>
  );
};

export default StudentBalanceProgress;
