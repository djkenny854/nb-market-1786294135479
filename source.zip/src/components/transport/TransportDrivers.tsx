
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit2, Phone, Plus, User } from 'lucide-react';

const TransportDrivers = () => {
  const drivers = [
    { id: 'd1', name: 'John Smith', phone: '+1 555-123-4567', license: 'DL12345678', experience: '8 years', assignedVehicle: 'Bus 01', status: 'on-duty' },
    { id: 'd2', name: 'Mary Johnson', phone: '+1 555-234-5678', license: 'DL23456789', experience: '5 years', assignedVehicle: 'Bus 03', status: 'on-duty' },
    { id: 'd3', name: 'Robert Brown', phone: '+1 555-345-6789', license: 'DL34567890', experience: '7 years', assignedVehicle: 'Van 02', status: 'off-duty' },
    { id: 'd4', name: 'Susan Davis', phone: '+1 555-456-7890', license: 'DL45678901', experience: '4 years', assignedVehicle: 'Bus 02', status: 'on-duty' },
    { id: 'd5', name: 'Michael Wilson', phone: '+1 555-567-8901', license: 'DL56789012', experience: '6 years', assignedVehicle: 'Van 01', status: 'on-leave' },
  ];

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'on-duty': return 'success';
      case 'off-duty': return 'outline';
      case 'on-leave': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Drivers Management</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Driver
        </Button>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>License No.</TableHead>
                <TableHead>Experience</TableHead>
                <TableHead>Assigned Vehicle</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {drivers.map((driver) => (
                <TableRow key={driver.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2 text-muted-foreground" />
                      {driver.name}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                      {driver.phone}
                    </div>
                  </TableCell>
                  <TableCell>{driver.license}</TableCell>
                  <TableCell>{driver.experience}</TableCell>
                  <TableCell>{driver.assignedVehicle}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={getStatusBadgeVariant(driver.status)}
                    >
                      {driver.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default TransportDrivers;
