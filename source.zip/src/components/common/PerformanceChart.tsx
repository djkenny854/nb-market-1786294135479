
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity } from 'lucide-react';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';

const chartData = [
  { subject: 'Math', score: 85, average: 76 },
  { subject: 'Science', score: 78, average: 72 },
  { subject: 'English', score: 92, average: 80 },
  { subject: 'History', score: 88, average: 75 },
  { subject: 'Arts', score: 95, average: 82 },
  { subject: 'PE', score: 90, average: 85 }
];

const chartConfig = {
  score: {
    label: 'Class Score',
    color: '#8B5CF6',
  },
  average: {
    label: 'School Average',
    color: '#94A3B8',
  }
};

const PerformanceChart = () => {
  return (
    <Card className="col-span-full backdrop-blur-sm bg-white/50 border border-white/20 shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Academic Performance</CardTitle>
        <Activity className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="pt-2">
        <ChartContainer config={chartConfig} className="aspect-[4/3] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="subject" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="score" fill="var(--color-score)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="average" fill="var(--color-average)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default PerformanceChart;
