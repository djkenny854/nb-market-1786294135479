
import React from "react";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export interface ClassOption {
  id: string;
  full_name: string;
}

interface ClassMultiSelectProps {
  options: ClassOption[];
  selected: string[];
  onChange: (selected: string[]) => void;
  label?: string;
}

const ClassMultiSelect: React.FC<ClassMultiSelectProps> = ({
  options,
  selected,
  onChange,
  label = "Applicable Classes"
}) => {
  const handleToggle = (id: string) => {
    if (selected.includes(id)) {
      onChange(selected.filter(cid => cid !== id));
    } else {
      onChange([...selected, id]);
    }
  };
  return (
    <div>
      <Label className="block mb-2">{label}</Label>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 border rounded-md bg-gray-50 dark:bg-slate-900">
        {options.map((opt) => (
          <label key={opt.id} className="flex items-center gap-2 cursor-pointer">
            <Checkbox
              checked={selected.includes(opt.id)}
              onCheckedChange={() => handleToggle(opt.id)}
              id={`class-opt-${opt.id}`}
            />
            <span>{opt.full_name}</span>
          </label>
        ))}
        {options.length === 0 && (
          <span className="italic text-muted-foreground">No classes found.</span>
        )}
      </div>
    </div>
  );
};

export default ClassMultiSelect;
