import React, { useEffect } from 'react';
import { Subject } from '@/types/subjects';
import { 
  Dialog, 
  DialogContent, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogDescription
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';

interface AddEditSubjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  subject: Subject | null;
  onSave: (subject: Subject) => void;
  categories: string[];
}

const formSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(2, { message: "Subject name is required" }),
  code: z.string().min(2, { message: "Subject code is required" }),
  category: z.string().min(1, { message: "Category is required" }),
  credits: z.coerce.number().min(1, { message: "Credits must be at least 1" }).max(10, { message: "Credits cannot exceed 10" }),
  description: z.string().optional(),
});

const AddEditSubjectDialog = ({ 
  open, 
  onOpenChange, 
  subject, 
  onSave,
  categories
}: AddEditSubjectDialogProps) => {
  const isEditing = !!subject;
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      id: "",
      name: "",
      code: "",
      category: "",
      credits: 1,
      description: "",
    },
  });

  useEffect(() => {
    if (subject) {
      form.reset({
        id: subject.id,
        name: subject.name,
        code: subject.code,
        category: subject.category,
        credits: subject.credits,
        description: subject.description || "",
      });
    } else {
      form.reset({
        id: "",
        name: "",
        code: "",
        category: "",
        credits: 1,
        description: "",
      });
    }
  }, [subject, form]);

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onSave({
      id: values.id || "0",
      name: values.name,
      code: values.code,
      category: values.category,
      credits: values.credits,
      description: values.description || "",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>{isEditing ? 'Edit Subject' : 'Add New Subject'}</DialogTitle>
          <DialogDescription>
            {isEditing ? 'Update the details of an existing subject.' : 'Enter details to create a new subject.'}
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Mathematics" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject Code</FormLabel>
                    <FormControl>
                      <Input placeholder="MAT101" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value || "default-category"}
                      value={field.value || "default-category"}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.length > 0 ? (
                          categories.map((category) => (
                            <SelectItem key={category} value={category || "unknown"}>{category || "Unknown"}</SelectItem>
                          ))
                        ) : (
                          <>
                            <SelectItem value="Core">Core</SelectItem>
                            <SelectItem value="Science">Science</SelectItem>
                            <SelectItem value="Humanities">Humanities</SelectItem>
                            <SelectItem value="Technology">Technology</SelectItem>
                            <SelectItem value="Arts">Arts</SelectItem>
                            <SelectItem value="Non-academic">Non-academic</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="credits"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credits</FormLabel>
                    <FormControl>
                      <Input type="number" min="1" max="10" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Brief description of the subject" 
                      className="resize-none" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit">
                {isEditing ? 'Save Changes' : 'Add Subject'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default AddEditSubjectDialog;
