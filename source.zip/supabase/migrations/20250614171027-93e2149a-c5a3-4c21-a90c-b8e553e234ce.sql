
-- Create inventory categories enum
CREATE TYPE public.inventory_category AS ENUM (
  'computers',
  'furniture',
  'lab_equipment',
  'sports_equipment',
  'books',
  'vehicles',
  'electronics',
  'office_supplies',
  'other'
);

-- Create inventory condition enum
CREATE TYPE public.inventory_condition AS ENUM (
  'excellent',
  'good',
  'fair',
  'poor',
  'damaged',
  'obsolete'
);

-- Create inventory status enum
CREATE TYPE public.inventory_status AS ENUM (
  'available',
  'in_use',
  'maintenance',
  'retired',
  'lost',
  'stolen'
);

-- Create inventory items table
CREATE TABLE public.inventory_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  category inventory_category NOT NULL,
  brand TEXT,
  model TEXT,
  serial_number TEXT UNIQUE,
  purchase_date DATE,
  purchase_cost NUMERIC(10,2),
  current_value NUMERIC(10,2),
  condition inventory_condition DEFAULT 'good',
  status inventory_status DEFAULT 'available',
  location TEXT,
  assigned_to TEXT, -- Can be teacher name, class, or department
  warranty_expiry DATE,
  maintenance_schedule TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by TEXT,
  updated_by TEXT
);

-- Create inventory transactions table for tracking movement/changes
CREATE TABLE public.inventory_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inventory_item_id UUID REFERENCES inventory_items(id) ON DELETE CASCADE,
  transaction_type TEXT NOT NULL, -- 'assignment', 'return', 'maintenance', 'transfer', 'disposal'
  from_location TEXT,
  to_location TEXT,
  assigned_from TEXT,
  assigned_to TEXT,
  notes TEXT,
  transaction_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  performed_by TEXT NOT NULL
);

-- Create leave types enum
CREATE TYPE public.leave_type AS ENUM (
  'annual',
  'sick',
  'maternity',
  'paternity',
  'emergency',
  'study',
  'unpaid',
  'compassionate'
);

-- Create leave status enum
CREATE TYPE public.leave_status AS ENUM (
  'pending',
  'approved',
  'rejected',
  'cancelled'
);

-- Create staff leave requests table
CREATE TABLE public.staff_leave_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  leave_type leave_type NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days_requested INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status leave_status DEFAULT 'pending',
  approved_by TEXT,
  approved_date TIMESTAMP WITH TIME ZONE,
  rejection_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create staff attendance table
CREATE TABLE public.staff_attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  check_in_time TIME,
  check_out_time TIME,
  hours_worked NUMERIC(4,2),
  status TEXT DEFAULT 'present', -- 'present', 'absent', 'late', 'half_day', 'on_leave'
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(teacher_id, date)
);

-- Create payroll records table
CREATE TABLE public.payroll_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  pay_period_start DATE NOT NULL,
  pay_period_end DATE NOT NULL,
  basic_salary NUMERIC(10,2) NOT NULL,
  allowances NUMERIC(10,2) DEFAULT 0,
  overtime_pay NUMERIC(10,2) DEFAULT 0,
  deductions NUMERIC(10,2) DEFAULT 0,
  tax_deductions NUMERIC(10,2) DEFAULT 0,
  net_pay NUMERIC(10,2) NOT NULL,
  pay_date DATE,
  status TEXT DEFAULT 'pending', -- 'pending', 'paid', 'cancelled'
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (you can restrict these later based on user roles)
CREATE POLICY "Allow all operations on inventory_items" ON public.inventory_items FOR ALL TO public WITH CHECK (true);
CREATE POLICY "Allow all operations on inventory_transactions" ON public.inventory_transactions FOR ALL TO public WITH CHECK (true);
CREATE POLICY "Allow all operations on staff_leave_requests" ON public.staff_leave_requests FOR ALL TO public WITH CHECK (true);
CREATE POLICY "Allow all operations on staff_attendance" ON public.staff_attendance FOR ALL TO public WITH CHECK (true);
CREATE POLICY "Allow all operations on payroll_records" ON public.payroll_records FOR ALL TO public WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX idx_inventory_items_category ON inventory_items(category);
CREATE INDEX idx_inventory_items_status ON inventory_items(status);
CREATE INDEX idx_inventory_items_assigned_to ON inventory_items(assigned_to);
CREATE INDEX idx_inventory_transactions_item_id ON inventory_transactions(inventory_item_id);
CREATE INDEX idx_staff_leave_requests_teacher_id ON staff_leave_requests(teacher_id);
CREATE INDEX idx_staff_leave_requests_status ON staff_leave_requests(status);
CREATE INDEX idx_staff_attendance_teacher_date ON staff_attendance(teacher_id, date);
CREATE INDEX idx_payroll_records_teacher_id ON payroll_records(teacher_id);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply the trigger to relevant tables
CREATE TRIGGER update_inventory_items_updated_at
    BEFORE UPDATE ON inventory_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_staff_leave_requests_updated_at
    BEFORE UPDATE ON staff_leave_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_staff_attendance_updated_at
    BEFORE UPDATE ON staff_attendance
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_payroll_records_updated_at
    BEFORE UPDATE ON payroll_records
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
