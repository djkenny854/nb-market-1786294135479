
import React from 'react';
import FeesUsageList from './FeesUsageList';

const FeesUsageTracker = () => {
  return <FeesUsageList />;
};

export default FeesUsageTracker;
