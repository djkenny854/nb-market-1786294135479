
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Teacher {
  id: string;
  name: string;
  employee_id: string;
  salary: number;
}

interface PayrollDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedMonth: string;
  onSuccess: () => void;
}

const PayrollDialog: React.FC<PayrollDialogProps> = ({
  open,
  onOpenChange,
  selectedMonth,
  onSuccess
}) => {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [formData, setFormData] = useState({
    teacher_id: '',
    basic_salary: '',
    allowances: '0',
    overtime_pay: '0',
    deductions: '0',
    tax_deductions: '0',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      fetchTeachers();
      setFormData({
        teacher_id: '',
        basic_salary: '',
        allowances: '0',
        overtime_pay: '0',
        deductions: '0',
        tax_deductions: '0',
        notes: ''
      });
    }
  }, [open]);

  const fetchTeachers = async () => {
    try {
      const { data, error } = await supabase
        .from('teachers')
        .select('id, name, employee_id, salary')
        .eq('status', 'active')
        .order('name');

      if (error) throw error;
      setTeachers(data || []);
    } catch (error) {
      console.error('Error fetching teachers:', error);
      toast({
        title: "Error",
        description: "Failed to fetch teachers list",
        variant: "destructive"
      });
    }
  };

  const handleTeacherSelect = (teacherId: string) => {
    const teacher = teachers.find(t => t.id === teacherId);
    setFormData({
      ...formData,
      teacher_id: teacherId,
      basic_salary: teacher?.salary?.toString() || '0'
    });
  };

  const calculateNetPay = () => {
    const basic = parseFloat(formData.basic_salary) || 0;
    const allowances = parseFloat(formData.allowances) || 0;
    const overtime = parseFloat(formData.overtime_pay) || 0;
    const deductions = parseFloat(formData.deductions) || 0;
    const tax = parseFloat(formData.tax_deductions) || 0;
    
    return basic + allowances + overtime - deductions - tax;
  };

  const getPayPeriod = () => {
    const start = new Date(selectedMonth + '-01');
    const end = new Date(start);
    end.setMonth(end.getMonth() + 1);
    end.setDate(0); // Last day of the month
    
    return {
      start: start.toISOString().slice(0, 10),
      end: end.toISOString().slice(0, 10)
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.teacher_id || !formData.basic_salary) {
      toast({
        title: "Error",
        description: "Please select a teacher and enter basic salary",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      const payPeriod = getPayPeriod();
      const netPay = calculateNetPay();

      const { error } = await supabase
        .from('payroll_records')
        .insert({
          teacher_id: formData.teacher_id,
          pay_period_start: payPeriod.start,
          pay_period_end: payPeriod.end,
          basic_salary: parseFloat(formData.basic_salary),
          allowances: parseFloat(formData.allowances) || 0,
          overtime_pay: parseFloat(formData.overtime_pay) || 0,
          deductions: parseFloat(formData.deductions) || 0,
          tax_deductions: parseFloat(formData.tax_deductions) || 0,
          net_pay: netPay,
          status: 'pending',
          notes: formData.notes || null
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Payroll record generated successfully"
      });

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error generating payroll:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to generate payroll record",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return `UGX ${amount.toLocaleString()}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Generate Payroll</DialogTitle>
          <DialogDescription>
            Generate payroll for {new Date(selectedMonth + '-01').toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="teacher">Teacher *</Label>
            <Select value={formData.teacher_id} onValueChange={handleTeacherSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Select a teacher" />
              </SelectTrigger>
              <SelectContent>
                {teachers.map((teacher) => (
                  <SelectItem key={teacher.id} value={teacher.id}>
                    {teacher.name} ({teacher.employee_id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="basic_salary">Basic Salary *</Label>
            <Input
              id="basic_salary"
              type="number"
              step="0.01"
              value={formData.basic_salary}
              onChange={(e) => setFormData({ ...formData, basic_salary: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="allowances">Allowances</Label>
              <Input
                id="allowances"
                type="number"
                step="0.01"
                value={formData.allowances}
                onChange={(e) => setFormData({ ...formData, allowances: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="overtime_pay">Overtime Pay</Label>
              <Input
                id="overtime_pay"
                type="number"
                step="0.01"
                value={formData.overtime_pay}
                onChange={(e) => setFormData({ ...formData, overtime_pay: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="deductions">Deductions</Label>
              <Input
                id="deductions"
                type="number"
                step="0.01"
                value={formData.deductions}
                onChange={(e) => setFormData({ ...formData, deductions: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="tax_deductions">Tax Deductions</Label>
              <Input
                id="tax_deductions"
                type="number"
                step="0.01"
                value={formData.tax_deductions}
                onChange={(e) => setFormData({ ...formData, tax_deductions: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              placeholder="Additional notes..."
            />
          </div>

          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="font-medium">Net Pay:</span>
              <span className="text-lg font-bold text-green-600">
                {formatCurrency(calculateNetPay())}
              </span>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Generating...' : 'Generate Payroll'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PayrollDialog;
