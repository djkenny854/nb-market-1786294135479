
import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Users, MessageSquare, DollarSign, GraduationCap } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Student {
  id: string;
  full_name: string;
  class: string;
}

interface StudentBulkActionsProps {
  selectedStudents: Student[];
  onClearSelection: () => void;
}

const StudentBulkActions: React.FC<StudentBulkActionsProps> = ({
  selectedStudents,
  onClearSelection
}) => {
  const [isActionModalOpen, setIsActionModalOpen] = useState(false);
  const [selectedAction, setSelectedAction] = useState('');
  const [newClass, setNewClass] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Migrate students mutation
  const migrateStudents = useMutation({
    mutationFn: async ({ studentIds, targetClass }: { studentIds: string[], targetClass: string }) => {
      // For now, we'll update students directly since the RPC function might not exist yet
      const { data, error } = await supabase
        .from('students')
        .update({ class: targetClass })
        .in('id', studentIds)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      const successful = data?.length || 0;
      
      toast({
        title: "Migration Complete",
        description: `${successful} students migrated successfully`
      });
      
      queryClient.invalidateQueries({ queryKey: ['students'] });
      onClearSelection();
      setIsActionModalOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Migration Failed",
        description: error.message || "Failed to migrate students",
        variant: "destructive"
      });
    }
  });

  const handleBulkAction = () => {
    if (selectedAction === 'migrate' && newClass) {
      migrateStudents.mutate({
        studentIds: selectedStudents.map(s => s.id),
        targetClass: newClass
      });
    }
  };

  const availableClasses = [
    'Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6', 'Primary 7',
    'Secondary 1', 'Secondary 2', 'Secondary 3', 'Secondary 4', 'Secondary 5', 'Secondary 6'
  ];

  if (selectedStudents.length === 0) {
    return null;
  }

  return (
    <>
      {/* Floating Action Bar */}
      <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-white shadow-lg rounded-lg p-4 border z-50">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="font-medium">{selectedStudents.length} student{selectedStudents.length > 1 ? 's' : ''} selected</span>
          </div>
          
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectedAction('migrate');
                setIsActionModalOpen(true);
              }}
            >
              <GraduationCap className="h-4 w-4 mr-1" />
              Migrate Class
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setSelectedAction('message');
                setIsActionModalOpen(true);
              }}
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              Send Message
            </Button>
            
            <Button size="sm" variant="outline" onClick={onClearSelection}>
              Clear
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <Dialog open={isActionModalOpen} onOpenChange={setIsActionModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedAction === 'migrate' && 'Migrate Students to New Class'}
              {selectedAction === 'message' && 'Send Message to Selected Students'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Selected Students Preview */}
            <div>
              <p className="text-sm font-medium mb-2">Selected Students:</p>
              <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto">
                {selectedStudents.map((student) => (
                  <Badge key={student.id} variant="outline">
                    {student.full_name} ({student.class})
                  </Badge>
                ))}
              </div>
            </div>

            {/* Migration Options */}
            {selectedAction === 'migrate' && (
              <div>
                <label className="text-sm font-medium">New Class</label>
                <Select value={newClass} onValueChange={setNewClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select new class" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableClasses.map((className) => (
                      <SelectItem key={className} value={className}>
                        {className}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Message Options */}
            {selectedAction === 'message' && (
              <div className="text-center py-4">
                <MessageSquare className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <p className="text-gray-600">
                  Messaging functionality will be integrated with the main messaging system.
                </p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsActionModalOpen(false)}
              >
                Cancel
              </Button>
              
              {selectedAction === 'migrate' && (
                <Button
                  onClick={handleBulkAction}
                  disabled={!newClass || migrateStudents.isPending}
                >
                  {migrateStudents.isPending ? 'Migrating...' : 'Migrate Students'}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default StudentBulkActions;
