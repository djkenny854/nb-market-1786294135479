
import { supabase } from '@/integrations/supabase/client';

export class MessageQueueService {
  static async processQueue(): Promise<{ success: boolean; processed: number }> {
    try {
      const { data, error } = await supabase.functions.invoke('process-message-queue', {
        body: {}
      });

      if (error) throw error;

      return {
        success: data?.success ?? false,
        processed: data?.processed ?? 0
      };
    } catch (error) {
      console.error('Error processing message queue:', error);
      return { success: false, processed: 0 };
    }
  }

  static async getQueueStatus(): Promise<{
    queued: number;
    processing: number;
    sent: number;
    failed: number;
  }> {
    try {
      // Query message_queue table for status counts (using type assertion until types are updated)
      const supabaseAny = supabase as any;
      const [queuedResult, processingResult, sentResult, failedResult] = await Promise.all([
        supabaseAny.from('message_queue').select('id', { count: 'exact', head: true }).eq('status', 'queued'),
        supabaseAny.from('message_queue').select('id', { count: 'exact', head: true }).eq('status', 'processing'),
        supabaseAny.from('message_queue').select('id', { count: 'exact', head: true }).eq('status', 'sent'),
        supabaseAny.from('message_queue').select('id', { count: 'exact', head: true }).eq('status', 'failed')
      ]);

      return {
        queued: queuedResult.count ?? 0,
        processing: processingResult.count ?? 0,
        sent: sentResult.count ?? 0,
        failed: failedResult.count ?? 0
      };
    } catch (error) {
      console.error('Error getting queue status:', error);
      return { queued: 0, processing: 0, sent: 0, failed: 0 };
    }
  }

  static async retryFailedMessages(): Promise<boolean> {
    try {
      // Update all failed messages to queued status for retry (using type assertion until types are updated)
      const { error } = await (supabase as any)
        .from('message_queue')
        .update({ status: 'queued', attempt_count: 0 })
        .eq('status', 'failed');

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error retrying failed messages:', error);
      return false;
    }
  }

  static async queueMessage(messageId: string, channel: 'sms' | 'email' | 'whatsapp', recipientContact: string, messageContent: string, subject?: string): Promise<boolean> {
    try {
      // Queue message (using type assertion until types are updated)
      const { error } = await (supabase as any)
        .from('message_queue')
        .insert({
          message_id: messageId,
          channel,
          recipient_contact: recipientContact,
          message_content: messageContent,
          subject,
          status: 'queued',
          scheduled_at: new Date().toISOString()
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error queueing message:', error);
      return false;
    }
  }
}
