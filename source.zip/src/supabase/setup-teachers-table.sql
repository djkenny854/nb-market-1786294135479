
-- Create the teachers table
CREATE TABLE IF NOT EXISTS teachers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT,
  subjects TEXT[],
  class_teacher_for TEXT,
  join_date TEXT NOT NULL,
  qualification TEXT,
  specialization TEXT,
  experience_years INTEGER,
  address TEXT,
  emergency_contact TEXT,
  profile_image TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ
);

-- Enable Row Level Security
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;

-- Create policy for SELECT - Allow anyone to view all teacher data in development
CREATE POLICY teachers_select_policy ON teachers
  FOR SELECT USING (true);

-- Create policy for INSERT - Only authenticated users can add teachers
CREATE POLICY teachers_insert_policy ON teachers
  FOR INSERT TO authenticated WITH CHECK (true);

-- Create policy for UPDATE - Only authenticated users can update teachers
CREATE POLICY teachers_update_policy ON teachers
  FOR UPDATE TO authenticated USING (true);

-- Create policy for DELETE - Only authenticated users can delete teachers
CREATE POLICY teachers_delete_policy ON teachers
  FOR DELETE TO authenticated USING (true);

-- Example of a production policy (commented out by default)
-- This would restrict teachers to only see their own data
-- CREATE POLICY teachers_select_own_data ON teachers
--   FOR SELECT TO authenticated
--   USING (auth.uid() = id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS teachers_class_teacher_for_idx ON teachers(class_teacher_for);
CREATE INDEX IF NOT EXISTS teachers_email_idx ON teachers(email);

-- Create trigger to update the updated_at timestamp
CREATE TRIGGER update_teachers_updated_at
BEFORE UPDATE ON teachers
FOR EACH ROW
EXECUTE PROCEDURE update_updated_at_column();
