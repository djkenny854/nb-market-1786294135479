export type AssessmentType = 'exam' | 'assignment' | 'test' | 'quiz' | 'project' | 'presentation' | 'practical' | 'homework' | 'classwork' | 'other';

export interface AssessmentCategory {
  id: string;
  name: string;
  description?: string;
  weight: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Assessment {
  id: string;
  title: string;
  description?: string;
  subject_id?: string;
  class_name: string;
  assessment_type: AssessmentType;
  category_id?: string;
  total_marks: number;
  due_date?: string;
  assessment_date: string;
  is_published: boolean;
  instructions?: string;
  created_by?: string;
  academic_year: string;
  academic_term: string;
  created_at: string;
  updated_at: string;
  
  // Joined data
  subject_name?: string;
  category?: AssessmentCategory;
}

export interface AssessmentGrade {
  id: string;
  assessment_id: string;
  student_id: string;
  marks_obtained: number;
  total_marks: number;
  percentage: number;
  grade?: string;
  teacher_comment?: string;
  submitted_at?: string;
  graded_at?: string;
  graded_by?: string;
  is_absent: boolean;
  late_submission: boolean;
  created_at: string;
  updated_at: string;
  
  // Joined data
  student_name?: string;
  assessment_title?: string;
  subject_name?: string;
}

export interface StudentAssessmentSummary {
  id: string;
  student_id: string;
  subject_id: string;
  class_name: string;
  academic_year: string;
  academic_term: string;
  total_assessments: number;
  completed_assessments: number;
  average_percentage: number;
  current_grade?: string;
  last_updated: string;
  created_at: string;
  updated_at: string;
  
  // Joined data
  student_name?: string;
  subject_name?: string;
}

export interface GradingStats {
  totalAssessments: number;
  gradedAssessments: number;
  pendingAssessments: number;
  averageScore: number;
  gradeDistribution: {
    A: number;
    B: number;
    C: number;
    D: number;
    F: number;
  };
}