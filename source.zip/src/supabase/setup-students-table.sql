
-- Create the students table with schema matching your Student type
CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  enrollment_number TEXT UNIQUE NOT NULL,
  date_of_birth TEXT,
  gender TEXT,
  class_id TEXT,
  class_name TEXT,
  parent_name TEXT,
  parent_contact TEXT,
  address TEXT,
  join_date TEXT,
  fees JSONB NOT NULL DEFAULT '{"paid": 0, "due": 0, "last_payment_date": null}'::JSONB,
  profile_image TEXT,
  email TEXT,
  blood_group TEXT,
  emergency_contact TEXT,
  medical_conditions TEXT,
  boarding_status TEXT,
  transport_use TEXT,
  best_color TEXT,
  clubs_activities TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ
);

-- Enable Row Level Security
ALTER TABLE students ENABLE ROW LEVEL SECURITY;

-- Create policy for SELECT - Allow anyone to view all student data in development
CREATE POLICY students_select_policy ON students
  FOR SELECT USING (true);

-- Create policy for INSERT - Only authenticated users can add students
CREATE POLICY students_insert_policy ON students
  FOR INSERT TO authenticated WITH CHECK (true);

-- Create policy for UPDATE - Only authenticated users can update students
CREATE POLICY students_update_policy ON students
  FOR UPDATE TO authenticated USING (true);

-- Create policy for DELETE - Only authenticated users can delete students
CREATE POLICY students_delete_policy ON students
  FOR DELETE TO authenticated USING (true);

-- Example of a production policy (commented out by default)
-- This would restrict students to only see their own data
-- CREATE POLICY students_select_own_data ON students
--   FOR SELECT TO authenticated
--   USING (auth.uid() = id);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS students_class_id_idx ON students(class_id);
CREATE INDEX IF NOT EXISTS students_enrollment_number_idx ON students(enrollment_number);

-- Create trigger to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_students_updated_at
BEFORE UPDATE ON students
FOR EACH ROW
EXECUTE PROCEDURE update_updated_at_column();
