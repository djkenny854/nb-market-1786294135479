import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { Clock, Users, AlertCircle, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AttendancePendingWidget = () => {
  const navigate = useNavigate();
  
  const { data: attendanceStats } = useQuery({
    queryKey: ['attendance-pending-stats'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      
      // Get all students
      const { data: students } = await supabase
        .from('students')
        .select('id, full_name, class');
      
      // Get today's attendance
      const { data: todayAttendance } = await supabase
        .from('attendance')
        .select('student_id, status')
        .eq('date', today);
      
      const totalStudents = students?.length || 0;
      const markedStudents = todayAttendance?.length || 0;
      const pendingStudents = totalStudents - markedStudents;
      
      // Get students not marked yet
      const markedStudentIds = todayAttendance?.map(a => a.student_id) || [];
      const unmarkedStudents = students?.filter(s => !markedStudentIds.includes(s.id)) || [];
      
      // Get present/absent counts
      const presentCount = todayAttendance?.filter(a => a.status === 'present').length || 0;
      const absentCount = todayAttendance?.filter(a => a.status === 'absent').length || 0;
      
      return {
        totalStudents,
        markedStudents,
        pendingStudents,
        unmarkedStudents: unmarkedStudents.slice(0, 5), // Show first 5
        presentCount,
        absentCount,
        attendanceRate: totalStudents > 0 ? Math.round((presentCount / totalStudents) * 100) : 0
      };
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (!attendanceStats) return null;

  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Clock className="h-5 w-5 text-orange-500" />
          Today's Attendance
        </CardTitle>
        <Badge variant={attendanceStats.pendingStudents > 0 ? "destructive" : "default"}>
          {attendanceStats.pendingStudents} Pending
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-2xl font-bold text-green-600 dark:text-green-400">
              <CheckCircle className="h-5 w-5" />
              {attendanceStats.presentCount}
            </div>
            <p className="text-xs text-muted-foreground">Present</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-2xl font-bold text-destructive">
              <AlertCircle className="h-5 w-5" />
              {attendanceStats.absentCount}
            </div>
            <p className="text-xs text-muted-foreground">Absent</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-2xl font-bold text-orange-600 dark:text-orange-400">
              <Users className="h-5 w-5" />
              {attendanceStats.pendingStudents}
            </div>
            <p className="text-xs text-muted-foreground">Pending</p>
          </div>
        </div>
        
        {/* Attendance Rate */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-foreground">Attendance Rate</span>
            <span className="font-medium text-foreground">{attendanceStats.attendanceRate}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${attendanceStats.attendanceRate}%` }}
            />
          </div>
        </div>

        {/* Pending Students Preview */}
        {attendanceStats.unmarkedStudents.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">Students Not Marked:</p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {attendanceStats.unmarkedStudents.map((student) => (
                <div key={student.id} className="flex justify-between items-center text-sm p-2 bg-orange-500/10 dark:bg-orange-500/20 rounded">
                  <span className="font-medium text-foreground">{student.full_name}</span>
                  <Badge variant="outline" className="text-xs">
                    {student.class}
                  </Badge>
                </div>
              ))}
            </div>
            {attendanceStats.pendingStudents > 5 && (
              <p className="text-xs text-muted-foreground">
                +{attendanceStats.pendingStudents - 5} more students
              </p>
            )}
          </div>
        )}
        
        <Button 
          onClick={() => navigate('/attendance')} 
          className="w-full"
          variant={attendanceStats.pendingStudents > 0 ? "default" : "outline"}
        >
          {attendanceStats.pendingStudents > 0 ? 'Mark Attendance' : 'View Attendance'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default AttendancePendingWidget;
