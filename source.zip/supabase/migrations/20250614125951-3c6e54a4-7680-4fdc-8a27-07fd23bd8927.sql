
-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Public Access" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can upload profile pictures" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can update profile pictures" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can delete profile pictures" ON storage.objects;

-- Create comprehensive policies for profile pictures bucket
CREATE POLICY "Enable read access for all users" ON storage.objects FOR SELECT USING (bucket_id = 'profile-pictures');

CREATE POLICY "Enable insert for all users" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'profile-pictures');

CREATE POLICY "Enable update for all users" ON storage.objects FOR UPDATE USING (bucket_id = 'profile-pictures');

CREATE POLICY "Enable delete for all users" ON storage.objects FOR DELETE USING (bucket_id = 'profile-pictures');
