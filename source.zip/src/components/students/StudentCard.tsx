
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import StudentBalanceProgress from '@/components/fees/StudentBalanceProgress';
import { Eye, GraduationCap, Home, Bus } from 'lucide-react';

interface StudentCardProps {
  student: {
    id: string;
    full_name: string;
    student_id: string;
    class: string;
    boarding_status?: string;
    transport?: string;
    profile_image_url?: string;
  };
  onViewDetails: (student: any) => void;
}

const StudentCard: React.FC<StudentCardProps> = ({ student, onViewDetails }) => {
  // Fetch student fee balance with real-time updates
  const { data: feeData, isLoading: feeLoading } = useQuery({
    queryKey: ['student-fee-balance', student.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('student_fees')
        .select('total_assigned_fees, total_paid, balance, payment_status')
        .eq('student_id', student.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds for real-time updates
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getBoardingBadgeColor = (status?: string) => {
    return status === 'Boarding' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800';
  };

  const getPaymentStatusColor = (status?: string) => {
    switch (status) {
      case 'Paid': return 'bg-green-100 text-green-800';
      case 'Partial': return 'bg-blue-100 text-blue-800';
      case 'Unpaid': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3">
            <Avatar className="w-12 h-12">
              <AvatarImage src={student.profile_image_url} alt={student.full_name} />
              <AvatarFallback className="text-sm">
                {getInitials(student.full_name)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-gray-900 text-sm">{student.full_name}</h3>
              <p className="text-gray-600 text-xs">ID: {student.student_id}</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onViewDetails(student)}
            className="flex items-center gap-1"
          >
            <Eye className="w-3 h-3" />
            View
          </Button>
        </div>

        <div className="flex flex-wrap gap-1 mb-3">
          <Badge variant="outline" className="flex items-center gap-1 text-xs">
            <GraduationCap className="w-3 h-3" />
            {student.class}
          </Badge>
          <Badge className={`${getBoardingBadgeColor(student.boarding_status)} text-xs`}>
            <Home className="w-3 h-3 mr-1" />
            {student.boarding_status || 'Day'}
          </Badge>
          {student.transport === 'Yes' && (
            <Badge className="bg-yellow-100 text-yellow-800 text-xs">
              <Bus className="w-3 h-3 mr-1" />
              Transport
            </Badge>
          )}
        </div>

        {/* Fee Balance Information with Circular Progress */}
        {feeLoading ? (
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse"></div>
            <div className="flex-1">
              <div className="h-3 bg-gray-200 rounded animate-pulse mb-2"></div>
              <div className="h-2 bg-gray-200 rounded animate-pulse"></div>
            </div>
          </div>
        ) : feeData ? (
          <div className="space-y-2">
            <div className="flex justify-between items-center mb-2">
              <Badge className={getPaymentStatusColor(feeData.payment_status)}>
                {feeData.payment_status || 'Unpaid'}
              </Badge>
            </div>
            <StudentBalanceProgress
              totalPaid={feeData.total_paid || 0}
              totalRequired={feeData.total_assigned_fees || 0}
              size="sm"
            />
          </div>
        ) : (
          <div className="text-xs text-gray-500 text-center py-2">
            No fee data available
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StudentCard;
