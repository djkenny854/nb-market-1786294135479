
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { PerformanceStats } from '@/types/exam';

// Sample data for the grade distribution
const gradeData = [
  { name: 'A', value: 25, color: '#10B981' },
  { name: 'B', value: 32, color: '#3B82F6' },
  { name: 'C', value: 28, color: '#F59E0B' },
  { name: 'D', value: 10, color: '#EF4444' },
  { name: 'F', value: 5, color: '#6B7280' }
];

// Configuration for the chart
const chartConfig = {
  A: { label: 'Grade A', color: '#10B981' },
  B: { label: 'Grade B', color: '#3B82F6' },
  C: { label: 'Grade C', color: '#F59E0B' },
  D: { label: 'Grade D', color: '#EF4444' },
  F: { label: 'Grade F', color: '#6B7280' }
};

interface GradeDistributionChartProps {
  stats?: PerformanceStats;
}

const GradeDistributionChart = ({ stats }: GradeDistributionChartProps) => {
  // Use provided stats or fallback to sample data
  const data = stats ? [
    { name: 'A', value: stats.gradeDistribution.A, color: '#10B981' },
    { name: 'B', value: stats.gradeDistribution.B, color: '#3B82F6' },
    { name: 'C', value: stats.gradeDistribution.C, color: '#F59E0B' },
    { name: 'D', value: stats.gradeDistribution.D, color: '#EF4444' },
    { name: 'F', value: stats.gradeDistribution.F, color: '#6B7280' }
  ] : gradeData;

  return (
    <Card className="col-span-1 backdrop-blur-sm bg-white/50 border border-white/20 shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Grade Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart margin={{ top: 0, right: 0, bottom: 30, left: 0 }}>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
                nameKey="name"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <ChartTooltip content={<ChartTooltipContent />} />
              <Legend
                layout="horizontal"
                align="center"
                verticalAlign="bottom"
                iconType="circle"
                iconSize={10}
              />
            </PieChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
};

export default GradeDistributionChart;
