
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';

interface AttendanceOverviewProps {
  attendanceData: Array<{
    className: string;
    totalStudents: number;
    present: number;
    absent: number;
    percentage: number;
    attendanceTaken: boolean;
  }>;
}

const AttendanceOverview: React.FC<AttendanceOverviewProps> = ({ attendanceData }) => {
  const totalPresent = attendanceData.reduce((sum, cls) => sum + (cls.attendanceTaken ? cls.present : 0), 0);
  const totalAbsent = attendanceData.reduce((sum, cls) => sum + (cls.attendanceTaken ? cls.absent : 0), 0);
  const classesWithAttendance = attendanceData.filter(cls => cls.attendanceTaken).length;
  const classesWithoutAttendance = attendanceData.filter(cls => !cls.attendanceTaken).length;

  const overallAttendanceData = [
    { name: 'Present', value: totalPresent, color: '#10b981' },
    { name: 'Absent', value: totalAbsent, color: '#ef4444' }
  ];

  const getStatusIcon = (attendanceTaken: boolean, percentage: number) => {
    if (!attendanceTaken) {
      return <Clock className="h-4 w-4 text-orange-500" />;
    }
    if (percentage >= 90) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    if (percentage >= 75) {
      return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
    return <XCircle className="h-4 w-4 text-red-500" />;
  };

  const getStatusBadge = (attendanceTaken: boolean, percentage: number) => {
    if (!attendanceTaken) {
      return <Badge variant="outline" className="text-orange-600 border-orange-600">Not Taken</Badge>;
    }
    if (percentage >= 90) {
      return <Badge variant="default" className="bg-green-600">Excellent</Badge>;
    }
    if (percentage >= 75) {
      return <Badge variant="default" className="bg-yellow-600">Good</Badge>;
    }
    return <Badge variant="destructive">Poor</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Overall Statistics */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Classes Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{classesWithAttendance}</div>
            <p className="text-xs text-muted-foreground">
              Out of {attendanceData.length} classes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Classes</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{classesWithoutAttendance}</div>
            <p className="text-xs text-muted-foreground">
              Attendance not taken
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Present</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{totalPresent}</div>
            <p className="text-xs text-muted-foreground">
              {totalPresent + totalAbsent > 0 ? ((totalPresent / (totalPresent + totalAbsent)) * 100).toFixed(1) : 0}% attendance rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Absent</CardTitle>
            <XCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{totalAbsent}</div>
            <p className="text-xs text-muted-foreground">
              {totalPresent + totalAbsent > 0 ? ((totalAbsent / (totalPresent + totalAbsent)) * 100).toFixed(1) : 0}% absence rate
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Overall Attendance Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Overall Attendance</CardTitle>
            <CardDescription>Distribution of present vs absent students</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              {totalPresent + totalAbsent > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={overallAttendanceData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {overallAttendanceData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <Clock className="h-12 w-12 mx-auto mb-2" />
                    <p>No attendance data available</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Class-wise Attendance List */}
        <Card>
          <CardHeader>
            <CardTitle>Class-wise Attendance</CardTitle>
            <CardDescription>Attendance status for each class today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-[300px] overflow-y-auto">
              {attendanceData.map((classData, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(classData.attendanceTaken, classData.percentage)}
                    <div>
                      <p className="font-medium">{classData.className}</p>
                      <p className="text-sm text-muted-foreground">
                        {classData.totalStudents} students
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(classData.attendanceTaken, classData.percentage)}
                    {classData.attendanceTaken && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {classData.present}/{classData.totalStudents} ({classData.percentage.toFixed(1)}%)
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AttendanceOverview;
