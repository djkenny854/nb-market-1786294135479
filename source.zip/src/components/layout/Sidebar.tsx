import React from 'react';
import {
  Home,
  Users,
  GraduationCap,
  BookOpen,
  Calendar,
  ClipboardCheck,
  DollarSign,
  MessageSquare,
  UserCheck,
  Package,
  Bus,
  FileText,
  Settings,
  MoreHorizontal,
} from 'lucide-react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useSiteSettings } from '@/context/SiteSettingsContext';
import ClassPilotLogo from '@/components/common/ClassPilotLogo';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

const Sidebar = () => {
  const { isSidebarOpen, sidebarMode, toggleSidebar, setSidebarOpen } = useSiteSettings();
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: 'Home', href: '/dashboard' },
    { icon: Users, label: 'Students', href: '/students' },
    { icon: GraduationCap, label: 'Teachers', href: '/teachers' },
    { icon: BookOpen, label: 'Classes', href: '/classes' },
    { icon: Calendar, label: 'Attendance', href: '/attendance' },
    { icon: ClipboardCheck, label: 'Exams', href: '/examinations' },
    { icon: DollarSign, label: 'Fees', href: '/fees' },
    { icon: MessageSquare, label: 'Messages', href: '/messaging' },
    { icon: UserCheck, label: 'HR', href: '/hr-payroll' },
    { icon: Package, label: 'Inventory', href: '/inventory' },
    { icon: Bus, label: 'Transport', href: '/transport' },
    { icon: FileText, label: 'Reports', href: '/reports' },
  ];

  const isCollapsed = !isSidebarOpen && !isMobile;

  // Handle navigation click - auto-collapse on mobile
  const handleNavClick = (href: string) => {
    if (isMobile) {
      setSidebarOpen(false);
    }
    navigate(href);
  };

  // For mobile, render inline (parent handles overlay)
  if (isMobile) {
    return (
      <div className="flex flex-col h-full bg-background">
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center gap-3">
          <ClassPilotLogo size={28} showText={true} />
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-3 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavClick(item.href)}
              className={cn(
                'flex items-center gap-5 px-6 py-3 transition-colors w-full text-left',
                'text-foreground hover:bg-accent'
              )}
            >
              <item.icon className="h-7 w-7 flex-shrink-0" strokeWidth={1.75} />
              <span className="text-xl">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Settings at bottom */}
        <div className="p-3 border-t border-border">
          <button
            onClick={() => handleNavClick('/settings')}
            className="flex items-center gap-5 px-6 py-3 w-full text-foreground hover:bg-accent transition-colors"
          >
            <Settings className="h-7 w-7" strokeWidth={1.75} />
            <span className="text-xl">Settings</span>
          </button>
          <button
            onClick={toggleSidebar}
            className="flex items-center gap-5 px-6 py-3 w-full text-foreground hover:bg-accent transition-colors"
          >
            <MoreHorizontal className="h-7 w-7" strokeWidth={1.75} />
            <span className="text-xl">Close</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'fixed left-0 top-0 h-full bg-background border-r border-border z-30 transition-all duration-200 flex flex-col',
        isCollapsed ? 'w-[68px]' : 'w-64'
      )}
    >
      {/* Header with Logo */}
      <div className="p-3 border-b border-border flex items-center justify-center h-14">
        {isCollapsed ? (
          <ClassPilotLogo size={28} showText={false} />
        ) : (
          <ClassPilotLogo size={28} showText={true} />
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-2 overflow-y-auto">
        {navItems.map((item) => {
          const NavItem = (
            <NavLink
              key={item.label}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-4 py-3 mx-2 rounded-full transition-colors',
                  isActive 
                    ? 'font-bold text-foreground' 
                    : 'text-foreground hover:bg-accent',
                  isCollapsed ? 'justify-center px-3' : 'px-4'
                )
              }
            >
              <item.icon className="h-6 w-6 flex-shrink-0" strokeWidth={1.75} />
              {!isCollapsed && (
                <span className="text-lg whitespace-nowrap">{item.label}</span>
              )}
            </NavLink>
          );

          if (isCollapsed) {
            return (
              <Tooltip key={item.label} delayDuration={0}>
                <TooltipTrigger asChild>
                  {NavItem}
                </TooltipTrigger>
                <TooltipContent side="right" className="ml-1">
                  {item.label}
                </TooltipContent>
              </Tooltip>
            );
          }

          return NavItem;
        })}
      </nav>

      {/* Settings + More at bottom */}
      <div className="p-2 border-t border-border space-y-1">
        {isCollapsed ? (
          <>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <NavLink
                  to="/settings"
                  className={({ isActive }) =>
                    cn(
                      'flex items-center justify-center py-3 mx-2 rounded-full transition-colors',
                      isActive ? 'font-bold text-foreground' : 'text-foreground hover:bg-accent'
                    )
                  }
                >
                  <Settings className="h-6 w-6" strokeWidth={1.75} />
                </NavLink>
              </TooltipTrigger>
              <TooltipContent side="right" className="ml-1">Settings</TooltipContent>
            </Tooltip>
            <Tooltip delayDuration={0}>
              <TooltipTrigger asChild>
                <button
                  onClick={toggleSidebar}
                  className="flex items-center justify-center py-3 mx-2 rounded-full transition-colors w-full text-foreground hover:bg-accent"
                >
                  <MoreHorizontal className="h-6 w-6" strokeWidth={1.75} />
                </button>
              </TooltipTrigger>
              <TooltipContent side="right" className="ml-1">Expand</TooltipContent>
            </Tooltip>
          </>
        ) : (
          <>
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-4 px-4 py-3 mx-2 rounded-full transition-colors',
                  isActive ? 'font-bold text-foreground' : 'text-foreground hover:bg-accent'
                )
              }
            >
              <Settings className="h-6 w-6" strokeWidth={1.75} />
              <span className="text-lg">Settings</span>
            </NavLink>
            <button
              onClick={toggleSidebar}
              className="flex items-center gap-4 px-4 py-3 mx-2 rounded-full transition-colors w-full text-foreground hover:bg-accent"
            >
              <MoreHorizontal className="h-6 w-6" strokeWidth={1.75} />
              <span className="text-lg">Collapse</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
