# Canonical project (NativeForge CPR)

This archive is machine generated. It is the canonical representation of the
uploaded source: framework **React**, build tool **Vite**,
Node **20**, Capacitor **7.x**.

The build pipeline consumes this archive only. The original upload is preserved
untouched under `original/source.zip`.
