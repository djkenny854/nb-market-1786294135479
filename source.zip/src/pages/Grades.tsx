import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, ClipboardList, BarChart3, FileSpreadsheet, Settings } from 'lucide-react';
import { useMobile } from '@/hooks/use-mobile';
import AssessmentManager from '@/components/grades/AssessmentManager';
import GradeEntry from '@/components/grades/GradeEntry';
import GradeReports from '@/components/grades/GradeReports';
import StudentGradebook from '@/components/grades/StudentGradebook';
import GradeSettings from '@/components/grades/GradeSettings';

const Grades = () => {
  const [activeTab, setActiveTab] = useState('assessments');
  const isMobile = useMobile();

  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Academic Grading</h1>
          <p className="text-muted-foreground mt-2">
            Manage assessments, record grades, and track academic performance.
          </p>
        </div>

        <Tabs defaultValue="assessments" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="assessments">
              <BookOpen className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Assessments</span>}
            </TabsTrigger>
            <TabsTrigger value="grading">
              <ClipboardList className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Grade Entry</span>}
            </TabsTrigger>
            <TabsTrigger value="gradebook">
              <FileSpreadsheet className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Gradebook</span>}
            </TabsTrigger>
            <TabsTrigger value="reports">
              <BarChart3 className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Reports</span>}
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Settings</span>}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="assessments" className="mt-6">
            <AssessmentManager />
          </TabsContent>
          
          <TabsContent value="grading" className="mt-6">
            <GradeEntry />
          </TabsContent>
          
          <TabsContent value="gradebook" className="mt-6">
            <StudentGradebook />
          </TabsContent>
          
          <TabsContent value="reports" className="mt-6">
            <GradeReports />
          </TabsContent>
          
          <TabsContent value="settings" className="mt-6">
            <GradeSettings />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Grades;