
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Search, Plus, Users, Edit, MoreHorizontal, ChevronRight, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

const classStreamSchema = z.object({
  class_level: z.string().min(1, 'Class level is required'),
  stream_name: z.string().min(1, 'Stream name is required'),
  class_teacher_id: z.string().optional(),
});

type ClassStreamFormData = z.infer<typeof classStreamSchema>;

interface ClassStream {
  id: string;
  class_level: string;
  stream_name: string;
  full_name: string;
  class_teacher_id?: string;
  student_count?: number;
  teacher_name?: string;
}

const ClassesManagement = () => {
  const [classStreams, setClassStreams] = useState<ClassStream[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState<ClassStream | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const form = useForm<ClassStreamFormData>({
    resolver: zodResolver(classStreamSchema),
    defaultValues: {
      class_level: '',
      stream_name: '',
      class_teacher_id: 'none',
    }
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [classStreamsResult, teachersResult] = await Promise.all([
        supabase.from('class_streams').select(`
          *,
          teacher:teachers(name)
        `).order('class_level'),
        supabase.from('teachers').select('id, name').order('name')
      ]);

      if (classStreamsResult.error) throw classStreamsResult.error;
      if (teachersResult.error) throw teachersResult.error;

      const classStreamData = classStreamsResult.data || [];
      const studentCounts = await Promise.all(
        classStreamData.map(async (classStream) => {
          const { count } = await supabase
            .from('students')
            .select('*', { count: 'exact', head: true })
            .eq('class', classStream.full_name);
          
          return {
            ...classStream,
            student_count: count || 0,
            teacher_name: classStream.teacher?.name
          };
        })
      );

      setClassStreams(studentCounts);
      setTeachers(teachersResult.data || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch class data",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const onSubmit = async (data: ClassStreamFormData) => {
    try {
      const classStreamData = {
        class_level: data.class_level,
        stream_name: data.stream_name,
        full_name: `${data.class_level} ${data.stream_name}`,
        class_teacher_id: data.class_teacher_id === 'none' ? null : data.class_teacher_id,
      };

      if (selectedClass) {
        const { error } = await supabase
          .from('class_streams')
          .update(classStreamData)
          .eq('id', selectedClass.id);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Class updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('class_streams')
          .insert(classStreamData);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Class created successfully"
        });
      }

      setIsAddDialogOpen(false);
      setSelectedClass(null);
      form.reset({
        class_level: '',
        stream_name: '',
        class_teacher_id: 'none',
      });
      fetchData();
    } catch (error: any) {
      console.error('Error saving class:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save class",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (classStream: ClassStream) => {
    setSelectedClass(classStream);
    form.setValue('class_level', classStream.class_level);
    form.setValue('stream_name', classStream.stream_name);
    form.setValue('class_teacher_id', classStream.class_teacher_id || 'none');
    setIsAddDialogOpen(true);
  };

  const handleDelete = async (classStreamId: string) => {
    if (!confirm('Are you sure you want to delete this class?')) return;

    try {
      const { error } = await supabase
        .from('class_streams')
        .delete()
        .eq('id', classStreamId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Class deleted successfully"
      });
      
      fetchData();
    } catch (error: any) {
      console.error('Error deleting class:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to delete class",
        variant: "destructive"
      });
    }
  };

  const filteredClasses = classStreams.filter(classStream =>
    classStream.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    classStream.teacher_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalStudents = classStreams.reduce((sum, c) => sum + (c.student_count || 0), 0);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Classes & Streams</h2>
        </div>
        <div className="space-y-1">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-16 bg-card/50 rounded animate-pulse border-b border-border"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header - X.com style */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border pb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold">Classes & Streams</h1>
            <p className="text-sm text-muted-foreground">
              {classStreams.length} streams · {totalStudents} students
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={() => { 
                  setSelectedClass(null); 
                  form.reset({
                    class_level: '',
                    stream_name: '',
                    class_teacher_id: 'none',
                  }); 
                }}
                className="rounded-full"
                size="sm"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {selectedClass ? 'Edit Class/Stream' : 'Add New Class/Stream'}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="class_level"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Class Level</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., Primary 5, Primary 6" className="bg-secondary border-0" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="stream_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Stream Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., East, West, A, B" className="bg-secondary border-0" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="class_teacher_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Class Teacher (Optional)</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-secondary border-0">
                              <SelectValue placeholder="Select class teacher" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">No teacher assigned</SelectItem>
                            {teachers.map(teacher => (
                              <SelectItem key={teacher.id} value={teacher.id}>
                                {teacher.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="ghost" onClick={() => setIsAddDialogOpen(false)} className="rounded-full">
                      Cancel
                    </Button>
                    <Button type="submit" className="rounded-full">
                      {selectedClass ? 'Update' : 'Create'}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search - X.com style */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search classes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-secondary border-0 rounded-full focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>
      </div>

      {/* Classes List - X.com style feed */}
      <div className="divide-y divide-border">
        {filteredClasses.map((classStream) => (
          <div 
            key={classStream.id} 
            className="py-3 px-2 hover:bg-secondary/50 transition-colors cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {/* Icon */}
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Users className="h-5 w-5 text-primary" />
                </div>

                {/* Content */}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-foreground">{classStream.full_name}</span>
                    <Badge variant="secondary" className="rounded-full text-xs px-2 py-0">
                      {classStream.stream_name}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{classStream.student_count || 0} students</span>
                    {classStream.teacher_name && (
                      <>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {classStream.teacher_name}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Quick Actions */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-primary/10 hover:text-primary">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={() => handleEdit(classStream)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Class
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => handleDelete(classStream.id)}
                      disabled={(classStream.student_count || 0) > 0}
                      className="text-destructive focus:text-destructive"
                    >
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredClasses.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <h3 className="font-semibold text-foreground mb-1">No classes found</h3>
          <p className="text-sm text-muted-foreground">
            {searchQuery ? 'Try a different search term' : 'Create your first class to get started'}
          </p>
        </div>
      )}
    </div>
  );
};

export default ClassesManagement;
