
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SchoolProfileData {
  id?: string;
  name: string;
  motto?: string;
  email?: string;
  phone?: string;
  website?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  postal_code?: string;
  logo_url?: string;
  term_start_date?: string;
  term_end_date?: string;
  academic_year?: string;
  current_term?: string;
}

export const useSchoolProfile = () => {
  const [profile, setProfile] = useState<SchoolProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('school_profile')
        .select('*')
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      setProfile(data || {
        name: '',
        motto: '',
        email: '',
        phone: '',
        website: '',
        address: '',
        city: '',
        state: '',
        country: '',
        postal_code: '',
        logo_url: '',
        term_start_date: '',
        term_end_date: '',
        academic_year: '2024',
        current_term: 'Term 1'
      });
    } catch (error) {
      console.error('Error fetching school profile:', error);
      toast.error('Failed to load school profile');
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (profileData: Partial<SchoolProfileData>) => {
    try {
      setLoading(true);
      
      // Ensure we have a name field for the upsert
      const dataToUpdate = {
        name: 'School Name', // Default value
        ...profileData
      };
      
      const { data, error } = await supabase
        .from('school_profile')
        .upsert(dataToUpdate)
        .select()
        .single();

      if (error) throw error;

      setProfile(data);
      toast.success('School profile updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating school profile:', error);
      toast.error('Failed to update school profile');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  return {
    profile,
    loading,
    updateProfile,
    refetch: fetchProfile
  };
};
