
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Database, Trash2, Archive, Download, Upload, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const DataManagement = () => {
  const [retentionPeriod, setRetentionPeriod] = useState('1year');
  const [autoArchive, setAutoArchive] = useState(true);
  const [autoCleanup, setAutoCleanup] = useState(false);
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings saved",
      description: "Data management settings have been updated."
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Data Management</h2>
        <p className="text-muted-foreground">Manage data retention, archiving, and cleanup policies.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="mr-2 h-5 w-5" />
              Data Retention
            </CardTitle>
            <CardDescription>Configure how long data is kept</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Student Records Retention</Label>
              <Select value={retentionPeriod || '1year'} onValueChange={setRetentionPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="6months">6 Months</SelectItem>
                  <SelectItem value="1year">1 Year</SelectItem>
                  <SelectItem value="2years">2 Years</SelectItem>
                  <SelectItem value="5years">5 Years</SelectItem>
                  <SelectItem value="indefinite">Indefinite</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Auto-Archive Old Records</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically move old records to archive
                </p>
              </div>
              <Switch checked={autoArchive} onCheckedChange={setAutoArchive} />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Auto-Cleanup Deleted Items</Label>
                <p className="text-xs text-muted-foreground">
                  Permanently delete items after 30 days
                </p>
              </div>
              <Switch checked={autoCleanup} onCheckedChange={setAutoCleanup} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Archive className="mr-2 h-5 w-5" />
              Archive Management
            </CardTitle>
            <CardDescription>Manage archived data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm">Current Archive Size: 2.3 GB</p>
              <p className="text-sm">Last Archive: 2 days ago</p>
              <p className="text-sm">Items in Archive: 1,247</p>
            </div>

            <div className="space-y-2">
              <Button variant="outline" className="w-full">
                <Archive className="mr-2 h-4 w-4" />
                View Archive
              </Button>
              <Button variant="outline" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export Archive
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Upload className="mr-2 h-5 w-5" />
              Data Import/Export
            </CardTitle>
            <CardDescription>Import or export school data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Export Format</Label>
              <Select defaultValue="csv">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Button variant="outline" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export All Data
              </Button>
              <Button variant="outline" className="w-full">
                <Upload className="mr-2 h-4 w-4" />
                Import Data
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Trash2 className="mr-2 h-5 w-5" />
              Data Cleanup
            </CardTitle>
            <CardDescription>Clean up unnecessary data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm">Temporary files: 125 MB</p>
              <p className="text-sm">Log files: 45 MB</p>
              <p className="text-sm">Cache files: 78 MB</p>
            </div>

            <div className="space-y-2">
              <Button variant="outline" className="w-full">
                <Trash2 className="mr-2 h-4 w-4" />
                Clean Temporary Files
              </Button>
              <Button variant="outline" className="w-full">
                <Trash2 className="mr-2 h-4 w-4" />
                Clear Cache
              </Button>
              <Button variant="destructive" className="w-full">
                <Trash2 className="mr-2 h-4 w-4" />
                Reset All Data
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSave} className="min-w-32">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default DataManagement;
