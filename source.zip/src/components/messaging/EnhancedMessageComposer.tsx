
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Send, Users, Eye, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable';
import AIMessageAssistant from './AIMessageAssistant';
import RecipientsList from './RecipientsList';
import { MessageQueueService } from '@/utils/messageQueueService';

interface ContactGroup {
  id: string;
  name: string;
  description?: string;
  group_type: string;
  member_ids: string[];
  is_dynamic?: boolean;
}

interface MessageTemplate {
  id: string;
  name: string;
  category: string;
  title: string;
  content: string;
  variables: string[];
}

interface EnhancedMessageComposerProps {
  templates?: MessageTemplate[];
  groups?: ContactGroup[];
  onMessageSent?: () => void;
}

const EnhancedMessageComposer: React.FC<EnhancedMessageComposerProps> = ({
  templates = [],
  groups = [],
  onMessageSent
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [channel, setChannel] = useState<'sms' | 'email' | 'whatsapp'>('sms');
  const [recipientType, setRecipientType] = useState<'individual' | 'group' | 'broadcast'>('group');
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [previewMode, setPreviewMode] = useState(false);
  const [sending, setSending] = useState(false);
  const [loadingRecipients, setLoadingRecipients] = useState(false);
  const [recipientCounts, setRecipientCounts] = useState<Record<string, number>>({});
  const [selectedRecipientIds, setSelectedRecipientIds] = useState<string[]>([]);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    const fetchRecipientCounts = async () => {
      if (groups.length === 0) return;
      setLoadingRecipients(true);
      const counts: Record<string, number> = {};

      await Promise.all(groups.map(async (group) => {
        try {
          const isTeacherGroup = group.group_type?.toLowerCase().includes('teacher');
          const table = isTeacherGroup ? 'teachers' : 'students';
          // For students: email field for email, parent_contact for SMS/WhatsApp
          // For teachers: email field for email, phone for SMS/WhatsApp
          const field = channel === 'email' ? 'email' : (isTeacherGroup ? 'phone' : 'parent_contact');

          if (group.is_dynamic || !group.member_ids || group.member_ids.length === 0) {
            // Dynamic group: count all valid contacts in table
            const { data } = await supabase
              .from(table)
              .select(`id, ${field}`)
              .not(field, 'is', null)
              .neq(field, '') as any;
            counts[group.id] = (data || []).length;
          } else {
            // Static group: count only within provided member_ids
            const { data } = await supabase
              .from(table)
              .select(`id, ${field}`)
              .in('id', group.member_ids)
              .not(field, 'is', null)
              .neq(field, '') as any;
            counts[group.id] = (data || []).length;
          }
        } catch (error) {
          console.error('Error fetching recipient count for group', group.id, error);
          counts[group.id] = 0;
        }
      }));

      setRecipientCounts(counts);
      setLoadingRecipients(false);
    };

    fetchRecipientCounts();
  }, [channel, groups]);

  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setTitle(template.title);
      setContent(template.content);
      setSelectedTemplate(templateId);
    }
  };

  const handleAISuggestionApply = (type: 'subject' | 'content', suggestion: string) => {
    if (type === 'subject') {
      setTitle(suggestion);
    } else {
      setContent(suggestion);
    }
    
    toast({
      title: "Applied!",
      description: `AI ${type} applied to your message.`,
    });
  };

  const sendMessage = async () => {
    if (!title.trim() || !content.trim() || selectedGroups.length === 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields and select recipients.",
        variant: "destructive",
      });
      return;
    }

    setSending(true);
    setProcessingStatus('Preparing message...');
    try {
      const scheduledAt = scheduledDate && scheduledTime 
        ? new Date(`${scheduledDate}T${scheduledTime}`)
        : null;

      // Step 1: Create message record
      const { data: messageData, error: messageError } = await supabase
        .from('messages')
        .insert({
          title,
          content,
          channel,
          recipient_type: recipientType,
          recipient_ids: selectedGroups,
          scheduled_at: scheduledAt?.toISOString(),
          status: 'pending',
        })
        .select()
        .single();

      if (messageError) throw messageError;

      setProcessingStatus('Fetching recipients...');

      // Helper function to replace template variables
      const replaceVariables = (text: string, recipientData: any): string => {
        const today = new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
        
        return text
          .replace(/\[PARENT_NAME\]/g, recipientData.parentName || 'Parent')
          .replace(/\[STUDENT_NAME\]/g, recipientData.studentName || 'Student')
          .replace(/\[DATE\]/g, today)
          .replace(/\[SCHOOL_NAME\]/g, 'School')
          .replace(/\[CLASS\]/g, recipientData.class || 'N/A')
          .replace(/\[CONTACT_NUMBER\]/g, recipientData.contact || '');
      };

      // Step 2: For each group, get member contacts with full data and queue individual messages
      let totalQueued = 0;
      for (const groupId of selectedGroups) {
        const { data: group } = await supabase
          .from('contact_groups')
          .select('id, group_type, is_dynamic, member_ids')
          .eq('id', groupId)
          .single();

        if (!group) continue;

        const isTeacherGroup = group.group_type?.toLowerCase().includes('teacher');
        const table = isTeacherGroup ? 'teachers' : 'students';
        const field = channel === 'email' ? 'email' : (isTeacherGroup ? 'phone' : 'parent_contact');

        // Fetch recipients with full data for variable replacement
        let recipients: any[] = [];
        if (group.is_dynamic || !group.member_ids || group.member_ids.length === 0) {
          const selectFields = isTeacherGroup 
            ? `id, first_name, last_name, ${field}`
            : `id, first_name, last_name, parent_name, class, ${field}`;
          
          const result: any = await supabase
            .from(table)
            .select(selectFields)
            .not(field, 'is', null)
            .neq(field, '');
          recipients = result.data || [];
        } else {
          const selectFields = isTeacherGroup 
            ? `id, first_name, last_name, ${field}`
            : `id, first_name, last_name, parent_name, class, ${field}`;
          
          const result: any = await supabase
            .from(table)
            .select(selectFields)
            .in('id', group.member_ids)
            .not(field, 'is', null)
            .neq(field, '');
          recipients = result.data || [];
        }

        // Filter by selected recipient IDs if any are specified
        if (selectedRecipientIds.length > 0) {
          recipients = recipients.filter((r: any) => selectedRecipientIds.includes(r.id));
        }

        if (recipients.length === 0) continue;

        setProcessingStatus(`Queuing messages for ${recipients.length} recipient(s)...`);

        // Queue messages with personalized content
        const records = recipients.map((r: any) => {
          const recipientData = {
            contact: r[field],
            parentName: r.parent_name || `${r.first_name}'s Parent`,
            studentName: `${r.first_name} ${r.last_name}`,
            class: r.class || 'N/A'
          };

          const personalizedSubject = replaceVariables(title, recipientData);
          const personalizedMessage = replaceVariables(content, recipientData);

          return {
            message_id: messageData.id,
            channel,
            recipient_contact: r[field],
            message_content: personalizedMessage,
            subject: personalizedSubject,
            status: 'queued',
            scheduled_at: scheduledAt?.toISOString() || new Date().toISOString()
          };
        });

        const { error: queueError } = await (supabase as any)
          .from('message_queue')
          .insert(records);

        if (!queueError) totalQueued += records.length;
      }

      // Process the queue immediately if not scheduled
      if (!scheduledAt) {
        setProcessingStatus('Processing message queue...');
        try {
          const result = await MessageQueueService.processQueue();
          if (result.success) {
            toast({
              title: "Messages Sent!",
              description: `Successfully processed ${result.processed} message(s) for ${totalQueued} recipient(s).`,
            });
          } else {
            toast({
              title: "Messages Queued",
              description: `${totalQueued} messages queued. Processing in progress.`,
            });
          }
        } catch (processError) {
          console.error('Queue processing error:', processError);
          toast({
            title: "Messages Queued",
            description: `${totalQueued} messages queued. Processing may take a moment.`,
          });
        }
      } else {
        toast({
          title: "Messages Scheduled!",
          description: `${totalQueued} messages scheduled for ${scheduledAt.toLocaleString()}`,
        });
      }

      // Reset form
      setTitle('');
      setContent('');
      setSelectedGroups([]);
      setSelectedRecipientIds([]);
      setScheduledDate('');
      setScheduledTime('');
      setSelectedTemplate('');

      if (onMessageSent) {
        onMessageSent();
      }

    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Send Failed",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSending(false);
      setProcessingStatus('');
    }
  };

  const getRecipientCount = () => {
    return selectedGroups.reduce((total, groupId) => {
      return total + (recipientCounts[groupId] || 0);
    }, 0);
  };

  return (
    <>
      {/* Loading Overlay */}
      {sending && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-card border rounded-lg p-8 shadow-lg flex flex-col items-center gap-4 max-w-md">
            <div className="relative">
              <Loader2 className="h-16 w-16 animate-spin text-primary" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">Sending Messages</h3>
              <p className="text-sm text-muted-foreground">{processingStatus}</p>
              <p className="text-xs text-muted-foreground">Please wait while we process your messages...</p>
            </div>
          </div>
        </div>
      )}
      
      <ResizablePanelGroup direction="horizontal" className="h-[calc(100vh-12rem)] gap-4">
      {/* Main Composer */}
      <ResizablePanel defaultSize={60} minSize={40}>
        <Card className="flex-1 flex flex-col overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <Send className="h-5 w-5" />
              Compose Message
            </CardTitle>
          </CardHeader>
          <ScrollArea className="flex-1">
            <CardContent className="space-y-4 sm:space-y-5 pb-6">
            {/* Template Selection */}
            {templates.length > 0 && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Template (Optional)</label>
                <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a template" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Channel Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Channel *</label>
              <Select value={channel} onValueChange={(value: 'sms' | 'email' | 'whatsapp') => setChannel(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Recipients */}
            {groups.length > 0 && (
              <div className="space-y-3">
                <label className="text-sm font-medium">Recipients *</label>
                {loadingRecipients ? (
                  <div className="space-y-2">
                    {groups.map((group) => (
                      <div key={group.id} className="flex items-center space-x-3 p-3 rounded-lg bg-muted/50">
                        <div className="h-4 w-4 rounded animate-pulse bg-muted-foreground/20" />
                        <div className="flex-1 space-y-2">
                          <div className="h-4 w-32 rounded animate-pulse bg-muted-foreground/20" />
                          <div className="h-3 w-24 rounded animate-pulse bg-muted-foreground/10" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {groups.map((group) => {
                      const count = recipientCounts[group.id] || 0;
                      const isDisabled = count === 0;
                      
                      return (
                        <div 
                          key={group.id} 
                          className={`flex items-center space-x-3 p-3 rounded-lg border transition-all ${
                            selectedGroups.includes(group.id) 
                              ? 'border-primary bg-primary/5' 
                              : 'border-border bg-background hover:bg-muted/50'
                          } ${isDisabled ? 'opacity-50' : ''}`}
                        >
                          <input
                            type="checkbox"
                            id={group.id}
                            checked={selectedGroups.includes(group.id)}
                            disabled={isDisabled}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedGroups([...selectedGroups, group.id]);
                              } else {
                                setSelectedGroups(selectedGroups.filter(id => id !== group.id));
                              }
                            }}
                            className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary disabled:cursor-not-allowed"
                          />
                          <label 
                            htmlFor={group.id} 
                            className={`flex-1 text-sm ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                              <span className="font-medium">{group.name}</span>
                              <div className="flex items-center gap-2">
                                <Badge 
                                  variant={count > 0 ? "default" : "secondary"} 
                                  className="text-xs"
                                >
                                  {count} {channel === 'email' ? 'emails' : 'contacts'}
                                </Badge>
                                {isDisabled && (
                                  <span className="text-xs text-muted-foreground">
                                    No {channel} contacts available
                                  </span>
                                )}
                              </div>
                            </div>
                          </label>
                        </div>
                      );
                    })}
                  </div>
                )}
                {!loadingRecipients && selectedGroups.length > 0 && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 text-primary">
                    <Users className="h-4 w-4 animate-pulse" />
                    <span className="font-medium">
                      {getRecipientCount()} recipients selected for {channel.toUpperCase()}
                    </span>
                  </div>
                )}
                {!loadingRecipients && getRecipientCount() === 0 && selectedGroups.length > 0 && (
                  <div className="text-sm text-destructive p-3 rounded-lg bg-destructive/10">
                    No valid {channel} contacts found in selected groups
                  </div>
                )}
              </div>
            )}

            {/* Message Content */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Subject/Title *</label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter message title..."
                className="text-sm sm:text-base"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Message Content *</label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Enter your message..."
                rows={6}
                className="text-sm sm:text-base resize-none"
              />
            </div>

            {/* Scheduling */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span className="truncate">Schedule Date (Optional)</span>
                </label>
                <Input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Schedule Time
                </label>
                <Input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  disabled={!scheduledDate}
                  className="text-sm"
                />
              </div>
            </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button
                  onClick={sendMessage}
                  disabled={sending || !title.trim() || !content.trim() || selectedGroups.length === 0 || (selectedRecipientIds.length === 0 && getRecipientCount() === 0) || loadingRecipients}
                  className="flex-1"
                >
                  {sending ? 'Sending...' : scheduledDate ? 'Schedule Message' : 'Send Now'}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setPreviewMode(!previewMode)}
                  className="sm:w-auto"
                >
                  <Eye className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Preview</span>
              </Button>
            </div>

            {/* Preview */}
            {previewMode && (
              <div className="mt-4 p-4 sm:p-6 border rounded-lg bg-gradient-to-br from-muted/50 to-muted">
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Eye className="h-4 w-4" />
                  Message Preview
                </h4>
                <div className="space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-start gap-1">
                    <strong className="text-sm min-w-20">Subject:</strong> 
                    <span className="text-sm">{title || 'No subject'}</span>
                  </div>
                  <div className="space-y-1">
                    <strong className="text-sm">Content:</strong>
                    <div className="whitespace-pre-wrap text-sm bg-background p-3 sm:p-4 rounded border">
                      {content || 'No content'}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground pt-2 border-t">
                    <span className="flex items-center gap-1">
                      <Badge variant="outline" className="text-xs">{channel.toUpperCase()}</Badge>
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {getRecipientCount()} recipients
                    </span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          </ScrollArea>
        </Card>
      </ResizablePanel>

      <ResizableHandle withHandle />

      {/* Right Column: AI Assistant + Recipients */}
      <ResizablePanel defaultSize={40} minSize={30}>
        <ResizablePanelGroup direction="vertical" className="h-full">
          {/* Recipients List */}
          <ResizablePanel defaultSize={55} minSize={30}>
            <RecipientsList
              selectedGroups={selectedGroups}
              channel={channel}
              groups={groups}
              onRecipientsChange={setSelectedRecipientIds}
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* AI Assistant */}
          <ResizablePanel defaultSize={45} minSize={30}>
            <div className="h-full overflow-hidden">
              <ScrollArea className="h-full">
                <AIMessageAssistant
                  category={selectedTemplate ? templates.find(t => t.id === selectedTemplate)?.category || 'custom' : 'custom'}
                  onSuggestionApply={handleAISuggestionApply}
                />
              </ScrollArea>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </ResizablePanel>
    </ResizablePanelGroup>
    </>
  );
};

export default EnhancedMessageComposer;
