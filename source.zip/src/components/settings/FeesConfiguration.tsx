
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FeeStructureManager from '@/components/fees/FeeStructureManager';

const FeesConfiguration = () => {
  return (
    <div className="space-y-6 bg-white">
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Fees Configuration</h1>
          <p className="text-gray-600 mt-2">
            Configure fee structures, manage class assignments, and set up automated fee calculations for students.
          </p>
        </div>

        <Tabs defaultValue="structures" className="space-y-6">
          <TabsList className="bg-gray-100 border border-gray-200">
            <TabsTrigger value="structures" className="text-gray-700 data-[state=active]:bg-white data-[state=active]:text-gray-900">
              Fee Structures
            </TabsTrigger>
            <TabsTrigger value="settings" className="text-gray-700 data-[state=active]:bg-white data-[state=active]:text-gray-900">
              Settings
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="structures" className="space-y-4 mt-6">
            <FeeStructureManager />
          </TabsContent>
          
          <TabsContent value="settings" className="space-y-4 mt-6">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Fee Management Settings</h3>
              <div className="space-y-4 text-gray-600">
                <p>• Automatic fee assignment when students are enrolled</p>
                <p>• Real-time balance calculations</p>
                <p>• Payment tracking and receipt generation</p>
                <p>• Multi-term and multi-year fee structures</p>
                <p>• Flexible fee components (tuition, boarding, transport, etc.)</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default FeesConfiguration;
