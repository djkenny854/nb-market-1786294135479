
-- Create teacher_salaries table
CREATE TABLE IF NOT EXISTS teacher_salaries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL DEFAULT 0,
  month TEXT NOT NULL,
  paid_on TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  method TEXT NOT NULL DEFAULT 'Cash',
  status TEXT NOT NULL DEFAULT 'Paid',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies for teacher_salaries
ALTER TABLE teacher_salaries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all operations on teacher_salaries" 
ON teacher_salaries FOR ALL 
USING (true) 
WITH CHECK (true);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS teacher_salaries_teacher_id_idx ON teacher_salaries(teacher_id);
CREATE INDEX IF NOT EXISTS teacher_salaries_month_idx ON teacher_salaries(month);
CREATE INDEX IF NOT EXISTS teacher_salaries_status_idx ON teacher_salaries(status);

-- Add salary column to teachers table if it doesn't exist
ALTER TABLE teachers ADD COLUMN IF NOT EXISTS salary NUMERIC DEFAULT 0;
