
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Book } from 'lucide-react';
import { Subject } from '@/types/subjects';

// Mock data for ongoing subjects - in a real app, this would come from a prop or context
const ongoingSubjects = [
  {
    id: '1',
    name: 'Mathematics',
    code: 'MATH101',
    teacher: 'Mr. Johnson',
    timeSlot: '09:00 AM - 10:30 AM',
    classroom: 'Room 101',
    progress: 65,
  },
  {
    id: '2',
    name: 'Physics',
    code: 'PHY102',
    teacher: 'Mrs. Smith',
    timeSlot: '10:45 AM - 12:15 PM',
    classroom: 'Lab 3',
    progress: 42,
  },
  {
    id: '3',
    name: 'English Literature',
    code: 'ENG201',
    teacher: 'Ms. Davis',
    timeSlot: '01:00 PM - 02:30 PM',
    classroom: 'Room 205',
    progress: 78,
  }
];

const OngoingSubjects = () => {
  return (
    <Card className="col-span-full md:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xl font-bold">Ongoing Subjects</CardTitle>
        <Clock className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {ongoingSubjects.map((subject) => (
            <div 
              key={subject.id} 
              className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg bg-card/50 backdrop-blur-sm border shadow-sm"
            >
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                  <Book className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">{subject.name}</h3>
                  <div className="text-sm text-muted-foreground flex flex-wrap gap-2 mt-1">
                    <span>{subject.teacher}</span>
                    <span>•</span>
                    <span>{subject.classroom}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col sm:items-end mt-2 sm:mt-0">
                <Badge variant="outline" className="mb-1">
                  {subject.timeSlot}
                </Badge>
                <div className="w-full sm:w-32 mt-1">
                  <div className="relative pt-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-semibold inline-block text-primary">
                          Progress
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold inline-block text-primary">
                          {subject.progress}%
                        </span>
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 mb-1 text-xs flex rounded bg-primary/20">
                      <div
                        style={{ width: `${subject.progress}%` }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default OngoingSubjects;
