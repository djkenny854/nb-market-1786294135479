
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMobile } from '@/hooks/use-mobile';
import { 
  School, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  User, 
  GraduationCap, 
  BookOpen,
  DollarSign,
  Edit,
  X,
  History,
  Heart,
  Users,
  FileText,
  Briefcase
} from 'lucide-react';
import TeacherSalaryCard from './TeacherSalaryCard';
import SalaryHistoryTable from './SalaryHistoryTable';

interface Teacher {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  subjects?: string[];
  class_teacher_for?: string;
  qualification?: string;
  specialization?: string;
  biography?: string;
  gender?: string;
  date_of_birth?: string;
  employee_id?: string;
  salary?: number;
  hire_date?: string;
  address?: string;
  emergency_contact?: string;
  profile_image_url?: string;
  status?: string;
  join_date?: string;
}

interface TeacherDetailViewProps {
  teacher: Teacher;
  onEdit: () => void;
  onClose: () => void;
}

const TeacherDetailView = ({ teacher, onEdit, onClose }: TeacherDetailViewProps) => {
  const isMobile = useMobile();
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const getStatusBadge = (status: string = 'active') => {
    const statusConfig = {
      active: { variant: 'default', label: 'Active', color: 'bg-green-100 text-green-800' },
      'on leave': { variant: 'secondary', label: 'On Leave', color: 'bg-yellow-100 text-yellow-800' },
      retired: { variant: 'outline', label: 'Retired', color: 'bg-gray-100 text-gray-800' },
      former: { variant: 'destructive', label: 'Former', color: 'bg-red-100 text-red-800' }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.active;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const formatSalary = (salary?: number) => {
    if (!salary) return 'Not set';
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: 'UGX'
    }).format(salary);
  };

  const calculateAge = (birthDate?: string) => {
    if (!birthDate) return 'Not specified';
    const today = new Date();
    const birth = new Date(birthDate);
    const age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      return age - 1;
    }
    return age;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Teacher Profile</h2>
        <div className="flex gap-2">
          <Button onClick={onEdit} variant="outline">
            <Edit className="h-4 w-4 mr-2" />
            Edit Profile
          </Button>
          <Button onClick={onClose} variant="ghost" size="icon">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Profile Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-6">
            <Avatar className="h-24 w-24">
              <AvatarImage src={teacher.profile_image_url || ''} alt={teacher.name} />
              <AvatarFallback className="text-2xl">
                {getInitials(teacher.name)}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-2">
              <div>
                <h3 className="text-2xl font-bold">{teacher.name}</h3>
                {teacher.employee_id && (
                  <p className="text-gray-600">Employee ID: {teacher.employee_id}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                {getStatusBadge(teacher.status)}
                {teacher.qualification && (
                  <Badge variant="outline" className="flex items-center gap-1">
                    <GraduationCap className="h-3 w-3" />
                    {teacher.qualification}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="profile">
            <User className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Profile</span>}
          </TabsTrigger>
          <TabsTrigger value="salary">
            <DollarSign className="h-4 w-4" />
            {!isMobile && <span className="ml-2">Salary</span>}
          </TabsTrigger>
          <TabsTrigger value="history">
            <History className="h-4 w-4" />
            {!isMobile && <span className="ml-2">History</span>}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Gender</label>
                    <p className="text-sm">{teacher.gender || 'Not specified'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Age</label>
                    <p className="text-sm">{calculateAge(teacher.date_of_birth)} years</p>
                  </div>
                </div>
                
                {teacher.date_of_birth && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Date of Birth</label>
                    <p className="text-sm flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {teacher.date_of_birth}
                    </p>
                  </div>
                )}

                {teacher.address && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Address</label>
                    <p className="text-sm flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {teacher.address}
                    </p>
                  </div>
                )}

                {teacher.emergency_contact && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Emergency Contact</label>
                    <p className="text-sm flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      {teacher.emergency_contact}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {teacher.email && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Email</label>
                    <p className="text-sm flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      <a href={`mailto:${teacher.email}`} className="text-blue-600 hover:underline">
                        {teacher.email}
                      </a>
                    </p>
                  </div>
                )}

                {teacher.phone && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Phone</label>
                    <p className="text-sm flex items-center gap-1">
                      <Phone className="h-3 w-3" />
                      <a href={`tel:${teacher.phone}`} className="text-blue-600 hover:underline">
                        {teacher.phone}
                      </a>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Professional Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Professional Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Qualification</label>
                    <p className="text-sm">{teacher.qualification || 'Not specified'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Specialization</label>
                    <p className="text-sm">{teacher.specialization || 'Not specified'}</p>
                  </div>
                </div>

                {teacher.hire_date && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Date Hired</label>
                    <p className="text-sm flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {teacher.hire_date}
                    </p>
                  </div>
                )}

                {teacher.salary && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Monthly Salary</label>
                    <p className="text-sm flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      <span className="font-medium text-green-600">{formatSalary(teacher.salary)}</span>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Teaching Assignment */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <School className="h-5 w-5" />
                  Teaching Assignment
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {teacher.class_teacher_for && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Class Teacher For</label>
                    <p className="text-sm">
                      <Badge variant="outline" className="flex items-center gap-1 w-fit">
                        <Users className="h-3 w-3" />
                        {teacher.class_teacher_for}
                      </Badge>
                    </p>
                  </div>
                )}

                {teacher.subjects && teacher.subjects.length > 0 && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">Subjects Taught</label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {teacher.subjects.map((subject, index) => (
                        <Badge key={index} variant="secondary" className="flex items-center gap-1">
                          <BookOpen className="h-3 w-3" />
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Biography */}
          {teacher.biography && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Biography
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-700 leading-relaxed">{teacher.biography}</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="salary" className="space-y-6">
          <TeacherSalaryCard 
            teacherId={teacher.id} 
            teacherName={teacher.name} 
            baseSalary={teacher.salary || 0}
          />
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <SalaryHistoryTable teacherId={teacher.id} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TeacherDetailView;
