
import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

const TimetableSkeleton: React.FC = () => {
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const periods = [1, 2, 3, 4, 5, 6, 7, 8];

  return (
    <div className="animate-fade-in">
      <div className="grid grid-cols-6 gap-2 min-w-[900px]">
        <div></div>
        {daysOfWeek.map((day, dayIndex) => (
          <div key={dayIndex} className="font-semibold text-center">
            <Skeleton className="h-6 w-20 mx-auto" />
          </div>
        ))}
        {periods.map((period) => (
          <React.Fragment key={period}>
            <div className="font-semibold text-center">
              <Skeleton className="h-6 w-8 mx-auto" />
            </div>
            {daysOfWeek.map((day, dayIndex) => (
              <div key={dayIndex} className="h-24 border border-border rounded-lg p-2 bg-card">
                <div className="space-y-2">
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default TimetableSkeleton;
