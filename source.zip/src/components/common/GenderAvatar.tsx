
import React from 'react';
import { User, UserCheck } from 'lucide-react';

interface GenderAvatarProps {
  gender?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const GenderAvatar: React.FC<GenderAvatarProps> = ({ 
  gender, 
  size = 'md',
  className = '' 
}) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-24 h-24',
    lg: 'w-32 h-32'
  };

  const iconSizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  const bgColor = gender?.toLowerCase() === 'male' 
    ? 'bg-blue-100 text-blue-600' 
    : gender?.toLowerCase() === 'female'
    ? 'bg-pink-100 text-pink-600'
    : 'bg-gray-100 text-gray-600';

  const IconComponent = gender?.toLowerCase() === 'female' ? UserCheck : User;

  return (
    <div className={`
      ${sizeClasses[size]} 
      ${bgColor} 
      rounded-full 
      flex 
      items-center 
      justify-center 
      border-2 
      border-gray-200
      ${className}
    `}>
      <IconComponent className={iconSizeClasses[size]} />
    </div>
  );
};

export default GenderAvatar;
