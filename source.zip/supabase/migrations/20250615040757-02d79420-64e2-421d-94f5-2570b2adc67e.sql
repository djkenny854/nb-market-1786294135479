
-- Ensure the fee assignment trigger is active for both INSERT and UPDATE

-- 1. Drop existing trigger if it exists (to avoid double triggers)
DROP TRIGGER IF EXISTS trg_auto_assign_student_fees ON public.students;

-- 2. Create a new trigger for automatic fee assignment
CREATE TRIGGER trg_auto_assign_student_fees
AFTER INSERT OR UPDATE OF class, boarding_status, transport
ON public.students
FOR EACH ROW
EXECUTE PROCEDURE public.auto_assign_student_fees();
