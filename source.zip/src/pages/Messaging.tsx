
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import MessagingDashboard from '@/components/messaging/MessagingDashboard';

const Messaging = () => {
  return (
    <MainLayout>
      <MessagingDashboard />
    </MainLayout>
  );
};

export default Messaging;
