import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { UserCheck, UserPlus, Shield, Edit, Trash2, Users, BookOpen } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { Database } from '@/integrations/supabase/types';

const teacherAssignmentSchema = z.object({
  teacher_id: z.string().min(1, 'Teacher selection is required'),
  role: z.enum(['class_teacher', 'subject_teacher', 'assistant']),
  subjects: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

const classRulesSchema = z.object({
  rule_type: z.enum(['discipline', 'academic', 'general', 'safety']),
  title: z.string().min(1, 'Rule title is required'),
  description: z.string().min(1, 'Rule description is required'),
  is_mandatory: z.boolean().default(true),
});

type TeacherAssignmentFormData = z.infer<typeof teacherAssignmentSchema>;
type ClassRulesFormData = z.infer<typeof classRulesSchema>;

type Teacher = Database['public']['Tables']['teachers']['Row'];
type ClassTeacher = Database['public']['Tables']['class_teachers']['Row'] & {
  teacher: Teacher;
};
type ClassRule = Database['public']['Tables']['class_rules']['Row'];
type Subject = Database['public']['Tables']['subjects']['Row'];

interface ClassTeacherManagementProps {
  className: string;
  onUpdate?: () => void;
}

const ClassTeacherManagement: React.FC<ClassTeacherManagementProps> = ({ 
  className, 
  onUpdate 
}) => {
  const [classTeachers, setClassTeachers] = useState<ClassTeacher[]>([]);
  const [classRules, setClassRules] = useState<ClassRule[]>([]);
  const [availableTeachers, setAvailableTeachers] = useState<Teacher[]>([]);
  const [availableSubjects, setAvailableSubjects] = useState<any[]>([]);
  const [isTeacherDialogOpen, setIsTeacherDialogOpen] = useState(false);
  const [isRulesDialogOpen, setIsRulesDialogOpen] = useState(false);
  const [selectedTeacherAssignment, setSelectedTeacherAssignment] = useState<ClassTeacher | null>(null);
  const [selectedRule, setSelectedRule] = useState<ClassRule | null>(null);
  const { toast } = useToast();

  const teacherForm = useForm<TeacherAssignmentFormData>({
    resolver: zodResolver(teacherAssignmentSchema),
    defaultValues: {
      teacher_id: '',
      role: 'subject_teacher',
      subjects: [],
      notes: '',
    }
  });

  const rulesForm = useForm<ClassRulesFormData>({
    resolver: zodResolver(classRulesSchema),
    defaultValues: {
      rule_type: 'general',
      title: '',
      description: '',
      is_mandatory: true,
    }
  });

  useEffect(() => {
    fetchData();
  }, [className]);

  const fetchData = async () => {
    try {
      // Fetch class teachers
      const { data: classTeachersData, error: teachersError } = await supabase
        .from('class_teachers')
        .select('*')
        .eq('class_name', className);

      if (teachersError) throw teachersError;

      // Fetch teacher details for class teachers
      const teacherIds = classTeachersData?.map(ct => ct.teacher_id) || [];
      const { data: teachersData, error: allTeachersError } = await supabase
        .from('teachers')
        .select('*')
        .in('id', teacherIds.length > 0 ? teacherIds : ['']);

      if (allTeachersError) throw allTeachersError;

      // Combine class teachers with teacher details
      const classTeachersWithDetails = classTeachersData?.map(ct => ({
        ...ct,
        teacher: teachersData?.find(t => t.id === ct.teacher_id) || {
          id: ct.teacher_id,
          name: 'Unknown Teacher',
          email: '',
          phone: '',
          profile_image_url: '',
          specialization: ''
        }
      })) || [];

      // Fetch class rules
      const { data: classRulesData, error: rulesError } = await supabase
        .from('class_rules')
        .select('*')
        .eq('class_name', className)
        .order('created_at');

      if (rulesError) throw rulesError;

      // Fetch all available teachers
      const { data: allTeachers, error: allTeachersListError } = await supabase
        .from('teachers')
        .select('*')
        .order('name');

      if (allTeachersListError) throw allTeachersListError;

      // Fetch subjects
      const { data: subjectsData, error: subjectsError } = await supabase
        .from('subjects')
        .select('*')
        .order('name');

      if (subjectsError) throw subjectsError;

      setClassTeachers(classTeachersWithDetails as any);
      setClassRules(classRulesData || []);
      setAvailableTeachers(allTeachers || []);
      setAvailableSubjects(subjectsData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch class data",
        variant: "destructive"
      });
    }
  };

  const onSubmitTeacher = async (data: TeacherAssignmentFormData) => {
    try {
      const teacherData = {
        class_name: className,
        teacher_id: data.teacher_id,
        role: data.role,
        subjects: data.subjects || [],
        notes: data.notes,
      };

      if (selectedTeacherAssignment) {
        const { error } = await supabase
          .from('class_teachers')
          .update(teacherData)
          .eq('id', selectedTeacherAssignment.id);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Teacher assignment updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('class_teachers')
          .insert(teacherData);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Teacher assigned successfully"
        });
      }

      setIsTeacherDialogOpen(false);
      setSelectedTeacherAssignment(null);
      teacherForm.reset();
      fetchData();
      onUpdate?.();
    } catch (error: any) {
      console.error('Error saving teacher assignment:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save teacher assignment",
        variant: "destructive"
      });
    }
  };

  const onSubmitRule = async (data: ClassRulesFormData) => {
    try {
      const ruleData = {
        class_name: className,
        rule_type: data.rule_type,
        title: data.title,
        description: data.description,
        is_mandatory: data.is_mandatory,
      };

      if (selectedRule) {
        const { error } = await supabase
          .from('class_rules')
          .update(ruleData)
          .eq('id', selectedRule.id);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Class rule updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('class_rules')
          .insert([ruleData]);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Class rule added successfully"
        });
      }

      setIsRulesDialogOpen(false);
      setSelectedRule(null);
      rulesForm.reset();
      fetchData();
    } catch (error: any) {
      console.error('Error saving class rule:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save class rule",
        variant: "destructive"
      });
    }
  };

  const handleEditTeacher = (teacher: ClassTeacher) => {
    setSelectedTeacherAssignment(teacher);
    teacherForm.setValue('teacher_id', teacher.teacher_id);
    teacherForm.setValue('role', teacher.role as any);
    teacherForm.setValue('subjects', teacher.subjects || []);
    teacherForm.setValue('notes', teacher.notes || '');
    setIsTeacherDialogOpen(true);
  };

  const handleDeleteTeacher = async (teacherId: string) => {
    if (!confirm('Are you sure you want to remove this teacher assignment?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('class_teachers')
        .delete()
        .eq('id', teacherId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Teacher assignment removed successfully"
      });
      
      fetchData();
      onUpdate?.();
    } catch (error: any) {
      console.error('Error removing teacher:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to remove teacher assignment",
        variant: "destructive"
      });
    }
  };

  const handleEditRule = (rule: ClassRule) => {
    setSelectedRule(rule);
    rulesForm.setValue('rule_type', rule.rule_type as any);
    rulesForm.setValue('title', rule.title);
    rulesForm.setValue('description', rule.description);
    rulesForm.setValue('is_mandatory', rule.is_mandatory);
    setIsRulesDialogOpen(true);
  };

  const handleDeleteRule = async (ruleId: string) => {
    if (!confirm('Are you sure you want to delete this class rule?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('class_rules')
        .delete()
        .eq('id', ruleId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Class rule deleted successfully"
      });
      
      fetchData();
    } catch (error: any) {
      console.error('Error deleting rule:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to delete class rule",
        variant: "destructive"
      });
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'class_teacher': return 'bg-blue-100 text-blue-800';
      case 'subject_teacher': return 'bg-green-100 text-green-800';
      case 'assistant': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRuleTypeColor = (type: string) => {
    switch (type) {
      case 'discipline': return 'bg-red-100 text-red-800';
      case 'academic': return 'bg-blue-100 text-blue-800';
      case 'general': return 'bg-green-100 text-green-800';
      case 'safety': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Teachers Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Assigned Teachers ({classTeachers.length})
            </CardTitle>
            <Dialog open={isTeacherDialogOpen} onOpenChange={setIsTeacherDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={() => {
                  setSelectedTeacherAssignment(null);
                  teacherForm.reset();
                }}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Assign Teacher
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {selectedTeacherAssignment ? 'Edit Teacher Assignment' : 'Assign Teacher'}
                  </DialogTitle>
                </DialogHeader>
                <Form {...teacherForm}>
                  <form onSubmit={teacherForm.handleSubmit(onSubmitTeacher)} className="space-y-4">
                    <FormField
                      control={teacherForm.control}
                      name="teacher_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Teacher</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select teacher" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableTeachers.map(teacher => (
                                <SelectItem key={teacher.id} value={teacher.id}>
                                  {teacher.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={teacherForm.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Role</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="class_teacher">Class Teacher</SelectItem>
                              <SelectItem value="subject_teacher">Subject Teacher</SelectItem>
                              <SelectItem value="assistant">Assistant Teacher</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={teacherForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes (Optional)</FormLabel>
                          <FormControl>
                            <Textarea {...field} placeholder="Additional notes about this assignment..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsTeacherDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        {selectedTeacherAssignment ? 'Update' : 'Assign'}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {classTeachers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <UserCheck className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No teachers assigned to this class yet</p>
              </div>
            ) : (
              classTeachers.map((classTeacher) => (
                <div key={classTeacher.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={classTeacher.teacher.profile_image_url} />
                      <AvatarFallback>
                        {classTeacher.teacher.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium">{classTeacher.teacher.name}</h4>
                      <div className="flex items-center gap-2">
                        <Badge className={getRoleColor(classTeacher.role)}>
                          {classTeacher.role.replace('_', ' ').toUpperCase()}
                        </Badge>
                        {classTeacher.teacher.specialization && (
                          <span className="text-xs text-muted-foreground">
                            {classTeacher.teacher.specialization}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditTeacher(classTeacher)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteTeacher(classTeacher.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Class Rules Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Class Rules ({classRules.length})
            </CardTitle>
            <Dialog open={isRulesDialogOpen} onOpenChange={setIsRulesDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" onClick={() => {
                  setSelectedRule(null);
                  rulesForm.reset();
                }}>
                  <Shield className="w-4 h-4 mr-2" />
                  Add Rule
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {selectedRule ? 'Edit Class Rule' : 'Add Class Rule'}
                  </DialogTitle>
                </DialogHeader>
                <Form {...rulesForm}>
                  <form onSubmit={rulesForm.handleSubmit(onSubmitRule)} className="space-y-4">
                    <FormField
                      control={rulesForm.control}
                      name="rule_type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Rule Type</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select rule type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="discipline">Discipline</SelectItem>
                              <SelectItem value="academic">Academic</SelectItem>
                              <SelectItem value="general">General</SelectItem>
                              <SelectItem value="safety">Safety</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={rulesForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Rule Title</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Enter rule title" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={rulesForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea {...field} placeholder="Describe the rule in detail..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsRulesDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        {selectedRule ? 'Update' : 'Add Rule'}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {classRules.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No class rules defined yet</p>
              </div>
            ) : (
              classRules.map((rule) => (
                <div key={rule.id} className="p-3 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge className={getRuleTypeColor(rule.rule_type)}>
                        {rule.rule_type.toUpperCase()}
                      </Badge>
                      {rule.is_mandatory && (
                        <Badge variant="outline" className="text-xs">
                          MANDATORY
                        </Badge>
                      )}
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEditRule(rule)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteRule(rule.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <h4 className="font-medium text-sm mb-1">{rule.title}</h4>
                  <p className="text-xs text-muted-foreground">{rule.description}</p>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClassTeacherManagement;