
export interface Subject {
  id: string;
  name: string;
  code: string;
  category: string;
  credits: number;
  description: string;
}
