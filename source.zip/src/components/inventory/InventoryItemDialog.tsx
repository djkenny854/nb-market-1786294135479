import React from 'react';
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Tables } from '@/integrations/supabase/types';

interface InventoryItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item?: Tables<'inventory_items'> | null;
  onSuccess: () => void;
}

const InventoryItemDialog: React.FC<InventoryItemDialogProps> = ({
  open,
  onOpenChange,
  item,
  onSuccess
}) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'computers',
    brand: '',
    model: '',
    serial_number: '',
    purchase_date: '',
    purchase_cost: '',
    current_value: '',
    condition: 'good',
    status: 'available',
    location: '',
    assigned_to: '',
    warranty_expiry: '',
    notes: '',
    // New fields for enhanced inventory system
    quantity: 1,
    cost: '',
    paid_from_fees: false,
    date_purchased: '',
    google_device_id: '',
    enrollment_status: 'not_enrolled'
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (item) {
      setFormData({
        name: item.name || '',
        description: item.description || '',
        category: item.category || 'computers',
        brand: item.brand || '',
        model: item.model || '',
        serial_number: item.serial_number || '',
        purchase_date: item.purchase_date || '',
        purchase_cost: item.purchase_cost?.toString() || '',
        current_value: item.current_value?.toString() || '',
        condition: item.condition || 'good',
        status: item.status || 'available',
        location: item.location || '',
        assigned_to: item.assigned_to || '',
        warranty_expiry: item.warranty_expiry || '',
        notes: item.notes || '',
        // Enhanced fields
        quantity: item.quantity || 1,
        cost: item.cost?.toString() || '',
        paid_from_fees: item.paid_from_fees || false,
        date_purchased: item.date_purchased || '',
        google_device_id: item.google_device_id || '',
        enrollment_status: item.enrollment_status || 'not_enrolled'
      });
    } else {
      setFormData({
        name: '',
        description: '',
        category: 'computers',
        brand: '',
        model: '',
        serial_number: '',
        purchase_date: '',
        purchase_cost: '',
        current_value: '',
        condition: 'good',
        status: 'available',
        location: '',
        assigned_to: '',
        warranty_expiry: '',
        notes: '',
        quantity: 1,
        cost: '',
        paid_from_fees: false,
        date_purchased: '',
        google_device_id: '',
        enrollment_status: 'not_enrolled'
      });
    }
  }, [item, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = {
        ...formData,
        purchase_cost: formData.purchase_cost ? parseFloat(formData.purchase_cost) : null,
        current_value: formData.current_value ? parseFloat(formData.current_value) : null,
        purchase_date: formData.purchase_date || null,
        warranty_expiry: formData.warranty_expiry || null,
        // Correct types for category, condition, status
        category: formData.category as Tables<'inventory_items'>['category'],
        condition: formData.condition as Tables<'inventory_items'>['condition'],
        status: formData.status as Tables<'inventory_items'>['status'],
        quantity: formData.quantity,
        cost: formData.cost ? parseFloat(formData.cost) : null,
        paid_from_fees: formData.paid_from_fees,
        date_purchased: formData.date_purchased || null,
        google_device_id: formData.google_device_id || null,
        enrollment_status: formData.enrollment_status
      };

      if (item) {
        const { error } = await supabase
          .from('inventory_items')
          .update(data)
          .eq('id', item.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Inventory item updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('inventory_items')
          .insert([data]);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Inventory item created successfully"
        });
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error saving inventory item:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save inventory item",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{item ? 'Edit Inventory Item' : 'Add New Inventory Item'}</DialogTitle>
          <DialogDescription>
            {item ? 'Update the inventory item details below.' : 'Fill in the details for the new inventory item.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Item Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="computers">Computers</SelectItem>
                  <SelectItem value="furniture">Furniture</SelectItem>
                  <SelectItem value="lab_equipment">Lab Equipment</SelectItem>
                  <SelectItem value="sports_equipment">Sports Equipment</SelectItem>
                  <SelectItem value="books">Books</SelectItem>
                  <SelectItem value="vehicles">Vehicles</SelectItem>
                  <SelectItem value="electronics">Electronics</SelectItem>
                  <SelectItem value="office_supplies">Office Supplies</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="brand">Brand</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="model">Model</Label>
              <Input
                id="model"
                value={formData.model}
                onChange={(e) => setFormData({ ...formData, model: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="serial_number">Serial Number</Label>
              <Input
                id="serial_number"
                value={formData.serial_number}
                onChange={(e) => setFormData({ ...formData, serial_number: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="purchase_date">Purchase Date</Label>
              <Input
                id="purchase_date"
                type="date"
                value={formData.purchase_date}
                onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="purchase_cost">Purchase Cost</Label>
              <Input
                id="purchase_cost"
                type="number"
                step="0.01"
                value={formData.purchase_cost}
                onChange={(e) => setFormData({ ...formData, purchase_cost: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="current_value">Current Value</Label>
              <Input
                id="current_value"
                type="number"
                step="0.01"
                value={formData.current_value}
                onChange={(e) => setFormData({ ...formData, current_value: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="condition">Condition</Label>
              <Select value={formData.condition} onValueChange={(value) => setFormData({ ...formData, condition: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">Excellent</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="poor">Poor</SelectItem>
                  <SelectItem value="damaged">Damaged</SelectItem>
                  <SelectItem value="obsolete">Obsolete</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="in_use">In Use</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                  <SelectItem value="lost">Lost</SelectItem>
                  <SelectItem value="stolen">Stolen</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g., Computer Lab, Office 101"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="assigned_to">Assigned To</Label>
              <Input
                id="assigned_to"
                value={formData.assigned_to}
                onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                placeholder="e.g., John Doe, Class 6A"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="warranty_expiry">Warranty Expiry</Label>
            <Input
              id="warranty_expiry"
              type="date"
              value={formData.warranty_expiry}
              onChange={(e) => setFormData({ ...formData, warranty_expiry: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
              placeholder="Additional notes about this item..."
            />
          </div>

          {/* Enhanced fields for new inventory system */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cost">Cost (UGX)</Label>
              <Input
                id="cost"
                type="number"
                step="0.01"
                value={formData.cost}
                onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="paid_from_fees"
              checked={formData.paid_from_fees}
              onChange={(e) => setFormData({ ...formData, paid_from_fees: e.target.checked })}
            />
            <Label htmlFor="paid_from_fees">Paid from student fees</Label>
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : item ? 'Update Item' : 'Add Item'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default InventoryItemDialog;
