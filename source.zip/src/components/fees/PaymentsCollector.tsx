
import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getAllActiveStudents, getStudentFeesForTerm, addStudentPayment, createStudentFeesRecord } from "@/utils/feesService";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

// Define a type for the payment input for the mutation
type PaymentInput = {
  studentId: string;
  amount: string;
  method: string;
};

export default function PaymentsCollector() {
  const queryClient = useQueryClient();
  
  const { data: students = [], isLoading: loadingStudents } = useQuery({
    queryKey: ["all_students"],
    queryFn: getAllActiveStudents,
  });

  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Cash");

  const { data: fees, refetch, isLoading: loadingFees } = useQuery({
    queryKey: ["student_fees", selectedStudent],
    queryFn: () => selectedStudent ? getStudentFeesForTerm(selectedStudent) : Promise.resolve(null),
    enabled: !!selectedStudent,
  });

  // Mutation to create student fees record if it doesn't exist
  const { mutate: createFees, isPending: creatingFees } = useMutation({
    mutationFn: (studentId: string) => createStudentFeesRecord(studentId),
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["student_fees"] });
    },
    onError: (e) => {
      console.error('Error creating student fees:', e);
      toast.error("Failed to create student fees record");
    },
  });

  // Properly type the mutation to accept PaymentInput argument
  const { mutate: submitPayment, isPending: loadingPay } = useMutation<void, Error, PaymentInput>({
    mutationFn: ({ studentId, amount, method }) =>
      addStudentPayment({ studentId, amount: Number(amount), method }),
    onSuccess: () => {
      toast.success("Payment recorded!");
      setAmount("");
      refetch();
      queryClient.invalidateQueries({ queryKey: ["student_fees"] });
      queryClient.invalidateQueries({ queryKey: ["fee_transactions"] });
    },
    onError: (e) => {
      console.error('Payment error:', e);
      toast.error("Failed to record payment", { description: e.message });
    },
  });

  const handleStudentSelect = (studentId: string) => {
    setSelectedStudent(studentId);
  };

  const handlePaymentSubmit = () => {
    if (!selectedStudent || !amount) {
      toast.error("Please select a student and enter an amount");
      return;
    }

    // If no fees record exists, create one first
    if (!fees) {
      createFees(selectedStudent);
      return;
    }

    submitPayment({ studentId: selectedStudent, amount, method });
  };

  if (loadingStudents) {
    return (
      <div className="p-4 w-full max-w-lg mx-auto bg-white dark:bg-slate-800 rounded">
        <Skeleton className="h-6 w-48 mb-4" />
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 w-full max-w-lg mx-auto bg-white dark:bg-slate-800 rounded">
      <h2 className="font-bold text-xl mb-3">Collect Payment</h2>
      <div className="mb-3">
        <Select value={selectedStudent ?? ""} onValueChange={handleStudentSelect}>
          <SelectTrigger>
            <SelectValue placeholder="Select student..." />
          </SelectTrigger>
          <SelectContent>
            {students.map(s => (
              <SelectItem key={s.id} value={s.id}>{s.full_name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {selectedStudent && loadingFees && (
        <div className="mb-4 space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      )}
      
      {selectedStudent && !fees && !loadingFees && (
        <div className="mb-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
          No fee record found for this student. Click "Record Payment" to create one.
        </div>
      )}
      
      {fees && (
        <div className="mb-2">
          <div className="text-sm text-gray-600 mb-1">
            Total Assigned: <span className="font-semibold">{Number(fees.total_assigned_fees).toLocaleString()}</span>
          </div>
          <div className="text-sm text-gray-600 mb-1">
            Total Paid: <span className="font-semibold">{Number(fees.total_paid).toLocaleString()}</span>
          </div>
          <div className="text-sm">
            Outstanding: <span className="font-semibold text-red-600">{Number(fees.balance).toLocaleString()}</span>
          </div>
        </div>
      )}
      
      <Input
        placeholder="Amount"
        type="number"
        className="mb-2"
        value={amount}
        onChange={e => setAmount(e.target.value)}
      />
      
      <Select value={method} onValueChange={setMethod}>
        <SelectTrigger>
          <SelectValue placeholder="Select method" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="Cash">Cash</SelectItem>
          <SelectItem value="Mobile Money">Mobile Money</SelectItem>
          <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
        </SelectContent>
      </Select>
      
      <Button
        disabled={!selectedStudent || !amount || loadingPay || creatingFees}
        className="mt-4 w-full"
        onClick={handlePaymentSubmit}
      >
        {loadingPay || creatingFees ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {creatingFees ? "Creating Record..." : "Processing..."}
          </>
        ) : (
          "Record Payment"
        )}
      </Button>
    </div>
  );
}
