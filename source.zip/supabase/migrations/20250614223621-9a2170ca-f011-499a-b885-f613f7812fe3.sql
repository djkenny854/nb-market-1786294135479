
-- Create table for linking fee_structures to classes (many-to-many)
CREATE TABLE public.fee_structure_classes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fee_structure_id UUID NOT NULL REFERENCES fee_structures(id) ON DELETE CASCADE,
  class_id UUID NOT NULL REFERENCES class_streams(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- (Optional, but recommended) Prevent duplicate fee_structure_id + class_id pairs
CREATE UNIQUE INDEX unique_fee_structure_class_pair
ON public.fee_structure_classes(fee_structure_id, class_id);

-- Enable RLS (if you want to restrict access) -- currently left open
ALTER TABLE public.fee_structure_classes ENABLE ROW LEVEL SECURITY;

-- Allow all roles full access (edit these policies if needed!)
CREATE POLICY "Allow all select fee structure classes" ON public.fee_structure_classes
  FOR SELECT USING (true);

CREATE POLICY "Allow all insert fee structure classes" ON public.fee_structure_classes
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow all update fee structure classes" ON public.fee_structure_classes
  FOR UPDATE USING (true);

CREATE POLICY "Allow all delete fee structure classes" ON public.fee_structure_classes
  FOR DELETE USING (true);

