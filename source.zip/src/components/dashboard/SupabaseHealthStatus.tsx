import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Database, Shield, Users, DollarSign, FileText } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useNetworkNotification } from '@/hooks/useNetworkNotification';
import { EyeOff, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
interface HealthCheck {
  name: string;
  status: 'success' | 'warning' | 'error';
  message: string;
  icon: React.ReactNode;
}
const statusStyles: { [key in HealthCheck['status']]: string } = {
  success: "border-green-200 bg-green-50 dark:bg-green-900 dark:border-green-700",
  warning: "border-yellow-200 bg-yellow-50 dark:bg-yellow-900 dark:border-yellow-700",
  error: "border-red-200 bg-red-50 dark:bg-red-900 dark:border-red-700"
};
const statusIcon: { [key in HealthCheck['status']]: React.ReactNode } = {
  success: <CheckCircle className="h-5 w-5 text-green-500" />,
  warning: <AlertCircle className="h-5 w-5 text-yellow-500" />,
  error: <AlertCircle className="h-5 w-5 text-red-500" />
};
const statusSummary: { [key in HealthCheck['status']]: {
  label: string;
  classes: string;
} } = {
  success: {
    label: "Healthy",
    classes: "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
  },
  warning: {
    label: "Warning",
    classes: "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100"
  },
  error: {
    label: "Error",
    classes: "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100"
  }
};
const SupabaseHealthStatus: React.FC = () => {
  const [healthChecks, setHealthChecks] = useState<HealthCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [hidden, setHidden] = useState(false);
  useNetworkNotification(); // <-- Enable notification + sound effect on network change

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Run the original health checks only online
    if (isOnline) {
      performHealthChecks();
    } else {
      // When offline, simulate all errors and show offline status
      setHealthChecks([{
        name: "Supabase Connection",
        status: "error",
        message: "No connection to Supabase, you appear to be offline.",
        icon: <Database className="h-5 w-5 text-primary" />
      }, {
        name: "Core Database Tables",
        status: "error",
        message: "Table checks unavailable (offline)",
        icon: <Users className="h-5 w-5 text-blue-500" />
      }, {
        name: "Fee Management System",
        status: "error",
        message: "Fee tables unavailable (offline)",
        icon: <DollarSign className="h-5 w-5 text-green-500" />
      }, {
        name: "Profile Pictures Storage",
        status: "error",
        message: "Storage status unavailable (offline)",
        icon: <FileText className="h-5 w-5 text-violet-500" />
      }, {
        name: "Row Level Security",
        status: "error",
        message: "RLS status unavailable (offline)",
        icon: <Shield className="h-5 w-5 text-indigo-500" />
      }]);
      setLoading(false);
    }
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
    // Only rerun effect if online status changes
    // eslint-disable-next-line
  }, [isOnline]);
  const performHealthChecks = async () => {
    setLoading(true);
    const checks: HealthCheck[] = [];

    // Check Supabase Connection
    try {
      const {
        error
      } = await supabase.from('students').select('count').limit(1);
      if (error) throw error;
      checks.push({
        name: 'Supabase Connection',
        status: 'success',
        message: 'Successfully connected to Supabase',
        icon: <Database className="h-5 w-5 text-primary" />
      });
    } catch (error) {
      checks.push({
        name: 'Supabase Connection',
        status: 'error',
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        icon: <Database className="h-5 w-5 text-primary" />
      });
    }

    // Check Core Tables Access
    try {
      const checkTable = async (tableName: string) => {
        try {
          await supabase.from(tableName as any).select('count').limit(1);
          return {
            table: tableName,
            success: true
          };
        } catch (error) {
          return {
            table: tableName,
            success: false,
            error
          };
        }
      };
      const tableChecks = await Promise.all([checkTable('students'), checkTable('teachers'), checkTable('class_streams'), checkTable('fee_structures'), checkTable('student_fees'), checkTable('fee_transactions')]);
      const failedTables = tableChecks.filter(check => !check.success);
      if (failedTables.length === 0) {
        checks.push({
          name: 'Core Database Tables',
          status: 'success',
          message: 'All required tables are accessible',
          icon: <Users className="h-5 w-5 text-blue-500" />
        });
      } else {
        checks.push({
          name: 'Core Database Tables',
          status: 'warning',
          message: `${failedTables.length} tables inaccessible: ${failedTables.map(t => t.table).join(', ')}`,
          icon: <Users className="h-5 w-5 text-blue-500" />
        });
      }
    } catch (error) {
      checks.push({
        name: 'Core Database Tables',
        status: 'error',
        message: 'Failed to check table access',
        icon: <Users className="h-5 w-5 text-blue-500" />
      });
    }

    // Check Fee Management System
    try {
      const {
        error: feeError
      } = await supabase.from('fee_structures').select('count').limit(1);
      const {
        error: studentFeeError
      } = await supabase.from('student_fees').select('count').limit(1);
      if (feeError || studentFeeError) {
        throw new Error('Fee system tables not accessible');
      }
      checks.push({
        name: 'Fee Management System',
        status: 'success',
        message: 'Fee structures and student fee tracking operational',
        icon: <DollarSign className="h-5 w-5 text-green-500" />
      });
    } catch (error) {
      checks.push({
        name: 'Fee Management System',
        status: 'error',
        message: `Fee system error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        icon: <DollarSign className="h-5 w-5 text-green-500" />
      });
    }

    // Check Storage Bucket
    try {
      const {
        data: buckets,
        error: bucketError
      } = await supabase.storage.listBuckets();
      if (bucketError) throw bucketError;
      const profilePicturesBucket = buckets?.find(bucket => bucket.name === 'profile-pictures');
      if (profilePicturesBucket) {
        checks.push({
          name: 'Profile Pictures Storage',
          status: 'success',
          message: 'Profile pictures storage bucket is ready',
          icon: <FileText className="h-5 w-5 text-violet-500" />
        });
      } else {
        checks.push({
          name: 'Profile Pictures Storage',
          status: 'warning',
          message: 'Profile pictures bucket not found',
          icon: <FileText className="h-5 w-5 text-violet-500" />
        });
      }
    } catch (error) {
      checks.push({
        name: 'Profile Pictures Storage',
        status: 'error',
        message: `Storage error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        icon: <FileText className="h-5 w-5 text-violet-500" />
      });
    }

    // Check RLS Status
    try {
      await supabase.from('students').select('id').limit(1);
      checks.push({
        name: 'Row Level Security',
        status: 'success',
        message: 'RLS is properly configured',
        icon: <Shield className="h-5 w-5 text-indigo-500" />
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      if (errorMessage.includes('row-level security')) {
        checks.push({
          name: 'Row Level Security',
          status: 'warning',
          message: 'RLS may be blocking access - check policies',
          icon: <Shield className="h-5 w-5 text-indigo-500" />
        });
      } else {
        checks.push({
          name: 'Row Level Security',
          status: 'error',
          message: `RLS check failed: ${errorMessage}`,
          icon: <Shield className="h-5 w-5 text-indigo-500" />
        });
      }
    }
    setHealthChecks(checks);
    setLoading(false);
  };
  const getOverallStatus = (): HealthCheck['status'] => {
    if (!isOnline) return "error";
    if (healthChecks.some(check => check.status === 'error')) return 'error';
    if (healthChecks.some(check => check.status === 'warning')) return 'warning';
    return 'success';
  };
  const summary = statusSummary[getOverallStatus()];
  if (hidden) {
    return <div className="w-full flex justify-center mb-4">
        <Button variant="outline" size="sm" aria-label="Show backend health status" className="mb-2" onClick={() => setHidden(false)}>
          <Eye className="mr-1 w-4 h-4" /> Show Backend Health Status
        </Button>
      </div>;
  }
  if (loading) {
    // Skeleton grid
    return <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-2">
          {Array.from({
          length: 6
        }).map((_, idx) => <Card key={idx} className="animate-pulse bg-muted/30">
              <CardHeader>
                <div className="h-4 w-24 bg-muted-foreground/20 mb-2 rounded" />
              </CardHeader>
              <CardContent>
                <div className="h-4 w-32 bg-muted-foreground/10 mb-2 rounded" />
                <div className="h-3 w-16 bg-muted-foreground/10 rounded" />
              </CardContent>
            </Card>)}
        </div>
      </div>;
  }
  return <div className="relative">
      {/* Hide button */}
      <Button variant="ghost" size="icon" aria-label="Hide backend health status" className="absolute top-2 right-2 z-10" onClick={() => setHidden(true)}>
        <EyeOff className="w-5 h-5" />
      </Button>
      {/* Summary/Overall card */}
      <Card className={`mb-6 border-2 shadow-md ${summary.classes}`}>
        <CardHeader className="flex flex-row items-center space-y-0 gap-3 p-4">
          <Database className="h-6 w-6 text-primary" />
          <CardTitle className="text-lg font-bold">Backend Status</CardTitle>
          <div className="ml-auto">
            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${summary.classes}`}>
              {isOnline ? summary.label : "Offline"}
            </span>
          </div>
        </CardHeader>
        {!isOnline && <div className="px-4 pb-4 text-red-600 font-semibold flex items-center gap-2">
            <span className="inline-block rounded-full bg-red-100 p-1 mr-2">
              <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M18.364 5.636a9 9 0 1 0 0 12.728m1.414-1.414A9 9 0 0 0 5.636 5.636m0 0A9 9 0 0 1 12 21a9 9 0 0 0 6.364-15.364z" /></svg>
            </span>
            The backend is unreachable. Please check your internet connection.
          </div>}
      </Card>
      {/* Responsive grid of health cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {healthChecks.map((check, index) => <Card key={index} className={`relative transition-all duration-200 transform hover:scale-[1.025] group
              ${!isOnline || check.status === "error" ? "border-red-200 bg-red-50 dark:bg-red-900 dark:border-red-700" : statusStyles[check.status]}
              border-2
            `}>
            <CardHeader className="flex flex-row items-center gap-2 py-4">
              <div className="rounded-full p-2 bg-white bg-opacity-70 dark:bg-slate-700 border">
                {check.icon}
              </div>
              <CardTitle className="text-base font-semibold">{check.name}</CardTitle>
              <div className="ml-auto">{statusIcon[!isOnline ? "error" : check.status]}</div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-700 dark:text-gray-200">{check.message}</div>
            </CardContent>
            <div className="absolute top-2 right-2">
              <Badge className={statusSummary[!isOnline ? "error" : check.status].classes + " px-2 py-1 text-xs font-bold"}>
                {isOnline ? statusSummary[check.status].label : "Offline"}
              </Badge>
            </div>
          </Card>)}
      </div>
    </div>;
};
export default SupabaseHealthStatus;