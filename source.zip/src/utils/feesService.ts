
import { supabase } from "@/integrations/supabase/client";

export async function getAllActiveStudents() {
  const { data, error } = await supabase
    .from("students")
    .select("id, full_name")
    .order("full_name");
  if (error) throw error;
  return data || [];
}

export async function getStudentFeesForTerm(studentId: string) {
  // Fetch fees for current academic year & term, or latest available
  const { data, error } = await supabase
    .from("student_fees")
    .select("*")
    .eq("student_id", studentId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function addStudentPayment({
  studentId,
  amount,
  method,
}: { studentId: string; amount: number; method: string; }) {
  // Get the student's current student_fees record
  const feeData = await getStudentFeesForTerm(studentId);
  if (!feeData) {
    // If no fee data exists, create it first by triggering the fee assignment
    await createStudentFeesRecord(studentId);
    const newFeeData = await getStudentFeesForTerm(studentId);
    if (!newFeeData) throw new Error("Failed to create student fees record.");
  }
  
  const currentYear = new Date().getFullYear().toString();
  const currentTerm = 'Term 1';
  
  const insert = {
    student_id: studentId,
    student_fee_id: feeData?.id,
    amount,
    payment_method: method,
    academic_year: currentYear,
    academic_term: currentTerm,
  };
  
  // Insert transaction only - let database triggers handle balance updates
  const { error } = await supabase.from("fee_transactions").insert(insert);
  if (error) throw error;
}

export async function createStudentFeesRecord(studentId: string) {
  // Get student data to calculate fees
  const { data: student, error: studentError } = await supabase
    .from("students")
    .select("*")
    .eq("id", studentId)
    .single();
    
  if (studentError) throw studentError;
  
  // Calculate fees based on student status
  let feeAmount = 500000; // Base tuition
  
  if (student.boarding_status === 'Boarding') {
    feeAmount += 300000;
  }
  
  if (student.transport === 'Yes') {
    feeAmount += 50000;
  }
  
  feeAmount += 25000; // Activities
  
  const currentYear = new Date().getFullYear().toString();
  const currentTerm = 'Term 1';
  
  // Insert student fees record (balance will be auto-calculated by database)
  const { error } = await supabase
    .from("student_fees")
    .insert({
      student_id: studentId,
      total_assigned_fees: feeAmount,
      total_paid: 0,
      academic_year: currentYear,
      academic_term: currentTerm,
      payment_status: 'Unpaid'
      // Don't set balance - it's auto-generated
    });
    
  if (error) throw error;
}

export async function getStudentTransactions(studentId: string) {
  const { data, error } = await supabase
    .from("fee_transactions")
    .select("*")
    .eq("student_id", studentId)
    .order("payment_date", { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function getDashboardFinanceStats() {
  // Returns { collected, outstanding }
  const { data, error } = await supabase
    .from("student_fees")
    .select("total_paid, balance");
  if (error) throw error;
  let collected = 0, outstanding = 0;
  data?.forEach(fee => {
    collected += Number(fee.total_paid || 0);
    outstanding += Number(fee.balance || 0);
  });
  return { collected, outstanding };
}

export async function getRecentFeeTransactions() {
  const { data, error } = await supabase
    .from("fee_transactions")
    .select("*, students(full_name)")
    .order("payment_date", { ascending: false })
    .limit(10);
  if (error) throw error;
  // Flatten result
  return (data || []).map(txn => ({
    ...txn,
    student_name: txn.students?.full_name || null
  }));
}

// Function to manually assign fees to all students who don't have them
export async function assignFeesToAllStudents() {
  try {
    const { error } = await supabase.rpc('assign_fees_to_students');
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error assigning fees to students:', error);
    throw error;
  }
}
