import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Database, HardDrive, RefreshCw, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import StorageBreakdown from './StorageBreakdown';
import DatabaseBreakdown from './DatabaseBreakdown';

interface StorageStats {
  storage: {
    used: number;
    total: number;
    percentage: number;
    breakdown: {
      studentFiles: { count: number; size: number };
      teacherFiles: { count: number; size: number };
      otherFiles: { count: number; size: number };
    };
  };
  database: {
    used: number;
    total: number;
    percentage: number;
    tableStats: {
      students: number;
      teachers: number;
      payments: number;
      feeTransactions: number;
      attendance: number;
      exams: number;
    };
  };
}

const StorageMonitoring = () => {
  const [stats, setStats] = useState<StorageStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchStorageStats = async () => {
    try {
      setIsRefreshing(true);
      
      // Get all storage buckets
      const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets();
      
      if (bucketsError) {
        console.error('Error fetching buckets:', bucketsError);
        toast.error('Failed to fetch storage data');
        return;
      }

      console.log('Available buckets:', buckets);

      let totalStorageUsed = 0;
      let studentFilesSize = 0, teacherFilesSize = 0, otherFilesSize = 0;
      let studentFilesCount = 0, teacherFilesCount = 0, otherFilesCount = 0;
      
      // Process each bucket
      for (const bucket of buckets || []) {
        try {
          console.log(`Processing bucket: ${bucket.name}`);
          
          // List all files in the bucket recursively
          const { data: files, error: filesError } = await supabase.storage
            .from(bucket.name)
            .list('', { limit: 1000, sortBy: { column: 'created_at', order: 'desc' } });
          
          if (filesError) {
            console.warn(`Error listing files in bucket ${bucket.name}:`, filesError);
            continue;
          }

          console.log(`Files in ${bucket.name}:`, files);
          
          if (files) {
            for (const file of files) {
              // Skip directories (they have no size)
              if (!file.metadata || file.metadata.size === undefined) {
                continue;
              }

              const fileSize = file.metadata.size || 0;
              totalStorageUsed += fileSize;
              
              console.log(`File: ${file.name}, Size: ${fileSize} bytes`);
              
              // Categorize files based on bucket name and file path
              const fileName = file.name.toLowerCase();
              const bucketName = bucket.name.toLowerCase();
              
              if (bucketName.includes('student') || fileName.includes('student')) {
                studentFilesSize += fileSize;
                studentFilesCount++;
              } else if (bucketName.includes('teacher') || fileName.includes('teacher') || bucketName.includes('profile')) {
                teacherFilesSize += fileSize;
                teacherFilesCount++;
              } else {
                otherFilesSize += fileSize;
                otherFilesCount++;
              }
            }
          }
        } catch (error) {
          console.warn(`Could not process bucket ${bucket.name}:`, error);
        }
      }

      console.log('Total storage calculated:', {
        total: totalStorageUsed,
        student: studentFilesSize,
        teacher: teacherFilesSize,
        other: otherFilesSize
      });

      // Get database table counts for more accurate estimation
      let tableStats = {
        students: 0,
        teachers: 0,
        payments: 0,
        feeTransactions: 0,
        attendance: 0,
        exams: 0
      };
      
      try {
        const [studentsCount, teachersCount, paymentsCount, feeTransactionsCount, attendanceCount, examsCount] = await Promise.all([
          supabase.from('students').select('*', { count: 'exact', head: true }),
          supabase.from('teachers').select('*', { count: 'exact', head: true }),
          supabase.from('payments').select('*', { count: 'exact', head: true }),
          supabase.from('fee_transactions').select('*', { count: 'exact', head: true }),
          supabase.from('attendance').select('*', { count: 'exact', head: true }),
          supabase.from('exams').select('*', { count: 'exact', head: true })
        ]);

        tableStats = {
          students: studentsCount.count || 0,
          teachers: teachersCount.count || 0,
          payments: paymentsCount.count || 0,
          feeTransactions: feeTransactionsCount.count || 0,
          attendance: attendanceCount.count || 0,
          exams: examsCount.count || 0
        };

        console.log('Database table stats:', tableStats);

      } catch (error) {
        console.warn('Could not fetch complete table counts:', error);
      }

      // Improved database size estimation (more realistic per-record sizes)
      const estimatedDbSize = (tableStats.students * 3072) +     // ~3KB per student (more fields)
                             (tableStats.teachers * 2048) +      // ~2KB per teacher
                             (tableStats.payments * 768) +       // ~768 bytes per payment
                             (tableStats.feeTransactions * 512) + // ~512 bytes per transaction
                             (tableStats.attendance * 384) +     // ~384 bytes per attendance
                             (tableStats.exams * 1536);          // ~1.5KB per exam

      // Set realistic limits based on Supabase free tier
      const storageLimit = 1 * 1024 * 1024 * 1024; // 1GB for free tier
      const databaseLimit = 500 * 1024 * 1024;     // 500MB for free tier

      const storagePercentage = Math.min((totalStorageUsed / storageLimit) * 100, 100);
      const databasePercentage = Math.min((estimatedDbSize / databaseLimit) * 100, 100);

      console.log('Final calculations:', {
        storageUsed: totalStorageUsed,
        storageLimit,
        storagePercentage,
        dbUsed: estimatedDbSize,
        dbLimit: databaseLimit,
        dbPercentage: databasePercentage
      });

      setStats({
        storage: {
          used: totalStorageUsed,
          total: storageLimit,
          percentage: storagePercentage,
          breakdown: {
            studentFiles: { count: studentFilesCount, size: studentFilesSize },
            teacherFiles: { count: teacherFilesCount, size: teacherFilesSize },
            otherFiles: { count: otherFilesCount, size: otherFilesSize }
          }
        },
        database: {
          used: estimatedDbSize,
          total: databaseLimit,
          percentage: databasePercentage,
          tableStats
        }
      });

    } catch (error) {
      console.error('Error fetching storage stats:', error);
      toast.error('Failed to fetch storage statistics');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchStorageStats();
  }, []);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5" />
            Storage & Database Usage
          </CardTitle>
          <CardDescription>
            Monitor your Supabase storage and database usage
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-2 bg-gray-200 rounded"></div>
            </div>
            <div className="animate-pulse">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-2 bg-gray-200 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getTotalUsed = () => {
    if (!stats) return 0;
    return stats.storage.used + stats.database.used;
  };

  const getTotalLimit = () => {
    if (!stats) return 1;
    return stats.storage.total + stats.database.total;
  };

  const formatGBValue = (bytes: number) => {
    return (bytes / (1024 * 1024 * 1024)).toFixed(2);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <HardDrive className="h-5 w-5" />
              Storage Usage
            </CardTitle>
            <CardDescription>
              Real-time monitoring of your Supabase storage and database
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchStorageStats}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {stats && (
          <>
            {/* Unified Storage Progress Bar */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold">
                  {formatGBValue(getTotalUsed())} GB of {formatGBValue(getTotalLimit())} GB used
                </span>
                <span className="text-sm text-muted-foreground">
                  {((getTotalUsed() / getTotalLimit()) * 100).toFixed(1)}% used
                </span>
              </div>
              
              {/* Single unified multi-segment progress bar */}
              <div className="relative w-full h-3 bg-muted rounded-full overflow-hidden">
                {/* Student files - Blue */}
                <div 
                  className="absolute top-0 left-0 h-full bg-blue-500 transition-all duration-500"
                  style={{ 
                    width: `${Math.min((stats.storage.breakdown.studentFiles.size / getTotalLimit()) * 100, 100)}%` 
                  }}
                  title={`Student Files: ${formatBytes(stats.storage.breakdown.studentFiles.size)}`}
                />
                {/* Teacher files - Orange */}
                <div 
                  className="absolute top-0 h-full bg-orange-500 transition-all duration-500"
                  style={{ 
                    left: `${Math.min((stats.storage.breakdown.studentFiles.size / getTotalLimit()) * 100, 100)}%`,
                    width: `${Math.min((stats.storage.breakdown.teacherFiles.size / getTotalLimit()) * 100, 100)}%` 
                  }}
                  title={`Teacher Files: ${formatBytes(stats.storage.breakdown.teacherFiles.size)}`}
                />
                {/* Other files - Yellow */}
                <div 
                  className="absolute top-0 h-full bg-yellow-500 transition-all duration-500"
                  style={{ 
                    left: `${Math.min(((stats.storage.breakdown.studentFiles.size + stats.storage.breakdown.teacherFiles.size) / getTotalLimit()) * 100, 100)}%`,
                    width: `${Math.min((stats.storage.breakdown.otherFiles.size / getTotalLimit()) * 100, 100)}%` 
                  }}
                  title={`Other Files: ${formatBytes(stats.storage.breakdown.otherFiles.size)}`}
                />
                {/* Database - Gray */}
                <div 
                  className="absolute top-0 h-full bg-gray-600 transition-all duration-500"
                  style={{ 
                    left: `${Math.min((stats.storage.used / getTotalLimit()) * 100, 100)}%`,
                    width: `${Math.min((stats.database.used / getTotalLimit()) * 100, 100)}%` 
                  }}
                  title={`Database: ${formatBytes(stats.database.used)}`}
                />
              </div>

              {/* Color-coded legend */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-blue-500 rounded"></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">Student Files</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(stats.storage.breakdown.studentFiles.size)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-orange-500 rounded"></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">Teacher Files</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(stats.storage.breakdown.teacherFiles.size)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">Other Files</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(stats.storage.breakdown.otherFiles.size)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-gray-600 rounded"></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium truncate">Database</div>
                    <div className="text-xs text-muted-foreground">{formatBytes(stats.database.used)}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Breakdown Tables */}
            <div className="grid md:grid-cols-2 gap-6 pt-6 border-t">
              {/* File Storage Details */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <HardDrive className="h-4 w-4 text-primary" />
                  <span className="font-semibold">File Storage</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center p-2 rounded bg-blue-50">
                    <span>Student Files ({stats.storage.breakdown.studentFiles.count})</span>
                    <span className="font-medium">{formatBytes(stats.storage.breakdown.studentFiles.size)}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-orange-50">
                    <span>Teacher Files ({stats.storage.breakdown.teacherFiles.count})</span>
                    <span className="font-medium">{formatBytes(stats.storage.breakdown.teacherFiles.size)}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-yellow-50">
                    <span>Other Files ({stats.storage.breakdown.otherFiles.count})</span>
                    <span className="font-medium">{formatBytes(stats.storage.breakdown.otherFiles.size)}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted font-semibold">
                    <span>Total Storage</span>
                    <span>{formatBytes(stats.storage.used)}</span>
                  </div>
                </div>
              </div>

              {/* Database Details */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Database className="h-4 w-4 text-primary" />
                  <span className="font-semibold">Database Records</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>Students</span>
                    <span className="font-medium">{stats.database.tableStats.students.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>Teachers</span>
                    <span className="font-medium">{stats.database.tableStats.teachers.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>Payments</span>
                    <span className="font-medium">{stats.database.tableStats.payments.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>Fee Transactions</span>
                    <span className="font-medium">{stats.database.tableStats.feeTransactions.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted/50">
                    <span>Attendance</span>
                    <span className="font-medium">{stats.database.tableStats.attendance.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center p-2 rounded bg-muted">
                    <span className="font-semibold">Est. DB Size</span>
                    <span className="font-semibold">{formatBytes(stats.database.used)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Usage Warnings */}
            {(stats.storage.percentage > 80 || stats.database.percentage > 80) && (
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                <p className="text-sm text-yellow-800">
                  ⚠️ You're approaching your storage limits. Consider upgrading your Supabase plan or cleaning up unused data.
                </p>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default StorageMonitoring;
