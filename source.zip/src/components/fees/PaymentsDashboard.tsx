import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { DollarSign, Calendar, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Payment } from '@/types/payment';
import { getPaymentStats } from '@/utils/paymentService';
import PaymentForm from './PaymentForm';
import { useData } from '@/context/DataSyncContext';

export function PaymentsDashboard() {
  const { students } = useData();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentFormOpen, setPaymentFormOpen] = useState(false);
  const [paymentStats, setPaymentStats] = useState({
    daily: 0,
    weekly: 0,
    monthly: 0,
    termly: 0,
    yearly: 0,
  });
  
  const [recentPayments, setRecentPayments] = useState<Payment[]>([]);

  // Fetch all students with payments
  useEffect(() => {
    const allPayments: Payment[] = [];
    
    // Extract payments from all students
    students.forEach(student => {
      if (student.payments && student.payments.length) {
        student.payments.forEach(payment => {
          allPayments.push({
            id: payment.id,
            studentId: student.id,
            studentName: student.name,
            amount: payment.amount,
            method: payment.method as any,
            description: payment.notes || '',
            receivedBy: payment.createdBy || 'System',
            academicTerm: 'Term 1',
            academicYear: new Date().getFullYear().toString(),
            createdAt: payment.date,
          });
        });
      }
    });
    
    // Sort payments by date (newest first)
    const sortedPayments = allPayments.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    setRecentPayments(sortedPayments);
    
    // Calculate payment statistics
    const calculateStats = async () => {
      try {
        const stats = {
          daily: 0,
          weekly: 0,
          monthly: 0,
          termly: 0,
          yearly: 0,
        };
        
        const now = new Date();
        const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
        const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay())).toISOString();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
        const startOfYear = new Date(now.getFullYear(), 0, 1).toISOString();
        
        // Calculate totals based on date ranges
        sortedPayments.forEach(payment => {
          const paymentDate = new Date(payment.createdAt);
          
          stats.yearly += payment.amount;
          
          if (paymentDate >= new Date(startOfYear)) {
            stats.yearly += payment.amount;
          }
          
          if (paymentDate >= new Date(startOfMonth)) {
            stats.monthly += payment.amount;
          }
          
          if (paymentDate >= new Date(startOfWeek)) {
            stats.weekly += payment.amount;
          }
          
          if (paymentDate >= new Date(startOfDay)) {
            stats.daily += payment.amount;
          }
        });
        
        stats.termly = stats.monthly;
        
        setPaymentStats(stats);
      } catch (error) {
        console.error("Error calculating payment stats:", error);
      }
    };
    
    calculateStats();
  }, [students]);
  
  // Filter payments based on search term
  const filteredPayments = recentPayments.filter(payment => 
    payment.studentName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    payment.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    payment.method.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-secondary">
          <TabsTrigger value="overview" className="text-xs sm:text-sm">Overview</TabsTrigger>
          <TabsTrigger value="record" className="text-xs sm:text-sm">Record</TabsTrigger>
          <TabsTrigger value="history" className="text-xs sm:text-sm">History</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="pt-3">
          {/* Compact stats grid */}
          <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 px-3 pt-3">
                <CardTitle className="text-xs font-medium text-muted-foreground">Today</CardTitle>
                <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
              </CardHeader>
              <CardContent className="px-3 pb-3">
                <div className="text-base sm:text-lg font-bold text-foreground truncate">UGX {paymentStats.daily.toLocaleString()}</div>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 px-3 pt-3">
                <CardTitle className="text-xs font-medium text-muted-foreground">Weekly</CardTitle>
                <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
              </CardHeader>
              <CardContent className="px-3 pb-3">
                <div className="text-base sm:text-lg font-bold text-foreground truncate">UGX {paymentStats.weekly.toLocaleString()}</div>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 px-3 pt-3">
                <CardTitle className="text-xs font-medium text-muted-foreground">Monthly</CardTitle>
                <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
              </CardHeader>
              <CardContent className="px-3 pb-3">
                <div className="text-base sm:text-lg font-bold text-foreground truncate">UGX {paymentStats.monthly.toLocaleString()}</div>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-1 px-3 pt-3">
                <CardTitle className="text-xs font-medium text-muted-foreground">Term</CardTitle>
                <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
              </CardHeader>
              <CardContent className="px-3 pb-3">
                <div className="text-base sm:text-lg font-bold text-foreground truncate">UGX {paymentStats.termly.toLocaleString()}</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent payments - responsive table */}
          <Card className="mt-4 bg-card border-border">
            <CardHeader className="px-4 pb-2">
              <CardTitle className="text-sm text-foreground">Recent Payments</CardTitle>
            </CardHeader>
            <CardContent className="px-0 pb-3">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead className="text-xs text-muted-foreground">Student</TableHead>
                      <TableHead className="text-xs text-muted-foreground">Amount</TableHead>
                      <TableHead className="text-xs text-muted-foreground hidden sm:table-cell">Method</TableHead>
                      <TableHead className="text-xs text-muted-foreground hidden md:table-cell">Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentPayments.slice(0, 5).map((payment) => (
                      <TableRow key={payment.id} className="border-border">
                        <TableCell className="text-xs text-foreground py-2 max-w-[120px] truncate">{payment.studentName}</TableCell>
                        <TableCell className="text-xs text-foreground py-2">UGX {payment.amount.toLocaleString()}</TableCell>
                        <TableCell className="text-xs text-foreground py-2 hidden sm:table-cell">{payment.method}</TableCell>
                        <TableCell className="text-xs text-foreground py-2 hidden md:table-cell">{new Date(payment.createdAt).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))}
                    {recentPayments.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4 text-muted-foreground text-xs">
                          No payments recorded
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="record" className="pt-3">
          <PaymentForm 
            students={students}
            onPaymentComplete={() => setActiveTab('overview')} 
          />
        </TabsContent>
        
        <TabsContent value="history" className="pt-3">
          <Card className="bg-card border-border">
            <CardHeader className="px-4 pb-2">
              <CardTitle className="text-sm text-foreground">Payment History</CardTitle>
              <div className="relative mt-2">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-8 bg-secondary border-border text-foreground"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardHeader>
            <CardContent className="px-0 pb-3">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead className="text-xs text-muted-foreground">Student</TableHead>
                      <TableHead className="text-xs text-muted-foreground">Amount</TableHead>
                      <TableHead className="text-xs text-muted-foreground hidden sm:table-cell">Method</TableHead>
                      <TableHead className="text-xs text-muted-foreground hidden md:table-cell">Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.map((payment) => (
                      <TableRow key={payment.id} className="border-border">
                        <TableCell className="text-xs text-foreground py-2 max-w-[120px] truncate">{payment.studentName}</TableCell>
                        <TableCell className="text-xs text-foreground py-2">UGX {payment.amount.toLocaleString()}</TableCell>
                        <TableCell className="text-xs text-foreground py-2 hidden sm:table-cell">{payment.method}</TableCell>
                        <TableCell className="text-xs text-foreground py-2 hidden md:table-cell">{new Date(payment.createdAt).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))}
                    {filteredPayments.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4 text-muted-foreground text-xs">
                          No payments found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default PaymentsDashboard;
