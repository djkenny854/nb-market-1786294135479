import React from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatItem {
  label: string;
  value: string | number;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  icon?: React.ReactNode;
}

interface CompactStatsProps {
  stats: StatItem[];
  className?: string;
}

const CompactStats: React.FC<CompactStatsProps> = ({ stats, className }) => {
  return (
    <div className={cn('grid grid-cols-2 lg:grid-cols-4 gap-3', className)}>
      {stats.map((stat, index) => (
        <div
          key={index}
          className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border hover:bg-accent/50 transition-colors"
        >
          {stat.icon && (
            <div className="flex-shrink-0 w-9 h-9 rounded-full bg-accent flex items-center justify-center text-foreground">
              {stat.icon}
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-semibold text-foreground truncate">
                {stat.value}
              </span>
              {stat.trend && (
                <span
                  className={cn(
                    'flex items-center text-xs font-medium',
                    stat.trend.isPositive ? 'text-primary' : 'text-destructive'
                  )}
                >
                  {stat.trend.isPositive ? (
                    <TrendingUp className="h-3 w-3 mr-0.5" />
                  ) : (
                    <TrendingDown className="h-3 w-3 mr-0.5" />
                  )}
                  {Math.abs(stat.trend.value)}%
                </span>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CompactStats;
