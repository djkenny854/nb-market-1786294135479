
import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { ChevronDown } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface GoogleSelectProps {
  label: string;
  value?: string;
  onValueChange?: (value: string) => void;
  children: React.ReactNode;
  error?: string;
  helperText?: string;
  placeholder?: string;
  className?: string;
}

const GoogleSelect: React.FC<GoogleSelectProps> = ({
  label,
  value,
  onValueChange,
  children,
  error,
  helperText,
  placeholder = "Select an option",
  className
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const hasValue = !!value;
  const isFloating = isFocused || hasValue;

  return (
    <div className="relative">
      <div className={cn("relative", className)}>
        <Select
          value={value}
          onValueChange={onValueChange}
          onOpenChange={setIsFocused}
        >
          <SelectTrigger
            className={cn(
              "w-full px-4 pt-6 pb-2 h-auto text-base bg-white border rounded-lg transition-all duration-200",
              "border-gray-300 hover:border-gray-400 focus:border-primary focus:ring-2 focus:ring-primary/20",
              "data-[state=open]:border-primary data-[state=open]:ring-2 data-[state=open]:ring-primary/20",
              error && "border-destructive focus:border-destructive focus:ring-destructive/20"
            )}
          >
            <SelectValue className="text-base" />
          </SelectTrigger>
          <SelectContent className="bg-white border shadow-lg max-h-60">
            {children}
          </SelectContent>
        </Select>
        
        <label
          className={cn(
            "absolute left-4 text-gray-500 transition-all duration-200 pointer-events-none select-none",
            isFloating
              ? "top-2 text-xs transform scale-90 origin-left text-primary"
              : "top-1/2 -translate-y-1/2 text-base",
            error && isFloating && "text-destructive"
          )}
        >
          {label}
        </label>
      </div>
      
      {(error || helperText) && (
        <div className="mt-1 text-xs">
          {error ? (
            <span className="text-destructive">{error}</span>
          ) : (
            <span className="text-muted-foreground">{helperText}</span>
          )}
        </div>
      )}
    </div>
  );
};

export { GoogleSelect };
export { SelectItem as GoogleSelectItem };
