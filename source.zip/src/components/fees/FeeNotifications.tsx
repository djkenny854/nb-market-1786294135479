
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Send, MessageCircle, Mail } from 'lucide-react';

interface Notification {
  id: string;
  type: 'reminder' | 'overdue' | 'payment_received';
  message: string;
  recipient: string;
  status: 'pending' | 'sent' | 'failed';
  date: string;
}

const FeeNotifications = () => {
  const [notifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'overdue',
      message: 'Fee payment overdue for John Doe - Class 7A',
      recipient: 'parent@email.com',
      status: 'sent',
      date: '2024-01-15'
    },
    {
      id: '2',
      type: 'reminder',
      message: 'Fee payment reminder for Sarah Smith - Class 6B',
      recipient: '+256700123456',
      status: 'pending',
      date: '2024-01-16'
    },
    {
      id: '3',
      type: 'payment_received',
      message: 'Payment received confirmation for Mike Johnson - Class 8A',
      recipient: 'parent2@email.com',
      status: 'sent',
      date: '2024-01-16'
    }
  ]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'sent':
        return <Badge variant="default">Sent</Badge>;
      case 'pending':
        return <Badge variant="warning">Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'reminder':
        return <Bell className="h-4 w-4" />;
      case 'overdue':
        return <MessageCircle className="h-4 w-4" />;
      case 'payment_received':
        return <Mail className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Fee Notifications & Reminders
            </CardTitle>
            <Button>
              <Send className="h-4 w-4 mr-2" />
              Send Bulk Reminders
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {notifications.map((notification) => (
              <div key={notification.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  {getTypeIcon(notification.type)}
                  <div>
                    <p className="font-medium">{notification.message}</p>
                    <p className="text-sm text-muted-foreground">
                      To: {notification.recipient} • {notification.date}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(notification.status)}
                  {notification.status === 'failed' && (
                    <Button variant="outline" size="sm">
                      Retry
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button variant="outline" className="w-full justify-start">
            <MessageCircle className="h-4 w-4 mr-2" />
            Send Overdue Reminders
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <Bell className="h-4 w-4 mr-2" />
            Send Weekly Reminders
          </Button>
          <Button variant="outline" className="w-full justify-start">
            <Mail className="h-4 w-4 mr-2" />
            Send Payment Confirmations
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeeNotifications;
