
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, FileText, Edit, Trash2, Copy } from 'lucide-react';
import { MessagingService } from '@/utils/messagingService';
import { MessageTemplate } from '@/types/messaging';
import { useToast } from '@/hooks/use-toast';

interface MessageTemplateManagerProps {
  templates: MessageTemplate[];
  onTemplateChange: () => void;
}

const MessageTemplateManager: React.FC<MessageTemplateManagerProps> = ({ templates, onTemplateChange }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplate | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    category: 'custom' as MessageTemplate['category'],
    title: '',
    content: '',
    variables: [] as string[],
    channels: [] as string[],
    is_default: false,
  });
  const [newVariable, setNewVariable] = useState('');
  const { toast } = useToast();

  const resetForm = () => {
    setFormData({
      name: '',
      category: 'custom',
      title: '',
      content: '',
      variables: [],
      channels: [],
      is_default: false,
    });
    setNewVariable('');
    setEditingTemplate(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (template: MessageTemplate) => {
    setFormData({
      name: template.name,
      category: template.category,
      title: template.title,
      content: template.content,
      variables: [...template.variables],
      channels: [...template.channels],
      is_default: template.is_default,
    });
    setEditingTemplate(template);
    setIsDialogOpen(true);
  };

  const handleSaveTemplate = async () => {
    if (!formData.name.trim() || !formData.title.trim() || !formData.content.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide name, title, and content for the template.",
        variant: "destructive",
      });
      return;
    }

    try {
      const templateData = {
        name: formData.name,
        category: formData.category,
        title: formData.title,
        content: formData.content,
        variables: formData.variables,
        channels: formData.channels,
        is_default: formData.is_default,
      };

      if (editingTemplate) {
        toast({
          title: "Info",
          description: "Template update functionality not yet implemented.",
        });
      } else {
        const result = await MessagingService.createTemplate(templateData);
        if (result) {
          toast({
            title: "Success",
            description: "Message template created successfully.",
          });
          onTemplateChange();
          setIsDialogOpen(false);
          resetForm();
        }
      }
    } catch (error) {
      console.error('Error saving template:', error);
      toast({
        title: "Error",
        description: "Failed to save message template.",
        variant: "destructive",
      });
    }
  };

  const addVariable = () => {
    if (newVariable.trim() && !formData.variables.includes(newVariable.trim())) {
      setFormData(prev => ({
        ...prev,
        variables: [...prev.variables, newVariable.trim()]
      }));
      setNewVariable('');
    }
  };

  const removeVariable = (variable: string) => {
    setFormData(prev => ({
      ...prev,
      variables: prev.variables.filter(v => v !== variable)
    }));
  };

  const toggleChannel = (channel: string) => {
    setFormData(prev => ({
      ...prev,
      channels: prev.channels.includes(channel)
        ? prev.channels.filter(c => c !== channel)
        : [...prev.channels, channel]
    }));
  };

  const getCategoryColor = (category: MessageTemplate['category']) => {
    switch (category) {
      case 'fee_reminder': return 'bg-red-100 text-red-800';
      case 'attendance_alert': return 'bg-yellow-100 text-yellow-800';
      case 'exam_result': return 'bg-blue-100 text-blue-800';
      case 'event_reminder': return 'bg-green-100 text-green-800';
      case 'announcement': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: MessageTemplate['category']) => {
    switch (category) {
      case 'fee_reminder': return '💰';
      case 'attendance_alert': return '⚠️';
      case 'exam_result': return '📊';
      case 'event_reminder': return '📅';
      case 'announcement': return '📢';
      default: return '📝';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Message Templates</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingTemplate ? 'Edit Message Template' : 'Create New Message Template'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter template name"
                />
              </div>

              <div className="space-y-2">
                <Label>Category</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value: MessageTemplate['category']) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="fee_reminder">Fee Reminder</SelectItem>
                    <SelectItem value="attendance_alert">Attendance Alert</SelectItem>
                    <SelectItem value="exam_result">Exam Result</SelectItem>
                    <SelectItem value="event_reminder">Event Reminder</SelectItem>
                    <SelectItem value="announcement">Announcement</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Subject/Title</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter message title"
                />
              </div>

              <div className="space-y-2">
                <Label>Message Content</Label>
                <Textarea
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Enter message content. Use [variable_name] for dynamic content."
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label>Variables</Label>
                <div className="flex gap-2">
                  <Input
                    value={newVariable}
                    onChange={(e) => setNewVariable(e.target.value)}
                    placeholder="Add variable name"
                    onKeyPress={(e) => e.key === 'Enter' && addVariable()}
                  />
                  <Button type="button" onClick={addVariable}>Add</Button>
                </div>
                <div className="flex flex-wrap gap-2 max-h-20 overflow-y-auto">
                  {formData.variables.map((variable) => (
                    <Badge key={variable} variant="secondary" className="cursor-pointer" onClick={() => removeVariable(variable)}>
                      {variable} ×
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Supported Channels</Label>
                <div className="flex gap-2">
                  {['sms', 'email', 'whatsapp'].map((channel) => (
                    <Button
                      key={channel}
                      type="button"
                      variant={formData.channels.includes(channel) ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleChannel(channel)}
                    >
                      {channel.toUpperCase()}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.is_default}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_default: checked }))}
                />
                <Label>Set as default template for this category</Label>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveTemplate}>
                  {editingTemplate ? 'Update' : 'Create'} Template
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template) => (
          <Card key={template.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getCategoryIcon(template.category)}</span>
                  <div>
                    <CardTitle className="text-sm">{template.name}</CardTitle>
                    <Badge className={`text-xs ${getCategoryColor(template.category)}`}>
                      {template.category.replace('_', ' ').toUpperCase()}
                    </Badge>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => openEditDialog(template)}>
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Copy className="h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>
                  <p className="text-xs font-medium">Title:</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{template.title}</p>
                </div>
                <div>
                  <p className="text-xs font-medium">Content:</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">{template.content}</p>
                </div>
                {template.variables.length > 0 && (
                  <div>
                    <p className="text-xs font-medium">Variables:</p>
                    <div className="flex flex-wrap gap-1">
                      {template.variables.slice(0, 3).map((variable) => (
                        <Badge key={variable} variant="outline" className="text-xs">
                          {variable}
                        </Badge>
                      ))}
                      {template.variables.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{template.variables.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div className="flex gap-1">
                    {template.channels.map((channel) => (
                      <Badge key={channel} variant="secondary" className="text-xs">
                        {channel.toUpperCase()}
                      </Badge>
                    ))}
                  </div>
                  {template.is_default && (
                    <Badge variant="default" className="text-xs">
                      Default
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  Created {new Date(template.created_at).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {templates.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">
              No message templates found. Create your first template to speed up message composition.
            </p>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Template
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MessageTemplateManager;
