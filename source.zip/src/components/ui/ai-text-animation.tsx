
import React, { useState, useEffect } from 'react';
import { Brain, Sparkles } from 'lucide-react';

interface AITextAnimationProps {
  texts: string[];
  className?: string;
  interval?: number;
  showIcon?: boolean;
}

const AITextAnimation: React.FC<AITextAnimationProps> = ({ 
  texts, 
  className = "", 
  interval = 2000,
  showIcon = true 
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % texts.length);
        setIsAnimating(false);
      }, 300);
    }, interval);

    return () => clearInterval(timer);
  }, [texts.length, interval]);

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {showIcon && (
        <div className="relative">
          <Brain className="h-4 w-4 text-purple-600 animate-pulse" />
          <Sparkles className="h-2 w-2 text-purple-400 absolute -top-1 -right-1 animate-bounce" />
        </div>
      )}
      <span 
        className={`transition-all duration-300 ${
          isAnimating ? 'opacity-0 transform scale-95' : 'opacity-100 transform scale-100'
        }`}
      >
        {texts[currentIndex]}
      </span>
    </div>
  );
};

export default AITextAnimation;
